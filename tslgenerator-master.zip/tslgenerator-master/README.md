# tslgenerator
TSL generator for the Category Partition Method

# TODO
- Changing the parsing of the files so that properties can be used even if they are declared later in the file
- Providing a GUI for the tool

