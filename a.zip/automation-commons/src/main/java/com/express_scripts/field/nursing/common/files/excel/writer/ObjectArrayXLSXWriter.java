package com.express_scripts.field.nursing.common.files.excel.writer;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;

import com.express_scripts.field.nursing.common.time.TimeUtils;

public class ObjectArrayXLSXWriter extends BaseReport{
	private final static Logger logger = Logger.getLogger(ObjectArrayXLSXWriter.class);
	
	private final List<Object[]> dataList;
	
	public static final String DEFAULT_REPORT = "etc\\excel\\objectArrayTemplate_v1.xlsx";
	
	protected static class Sheets{
		protected static final String Data = "Sheet1";
		
	}
	
    public ObjectArrayXLSXWriter(List<Object[]> dataList, Path reportPath, Path masterReportPath) {
    	super(reportPath, masterReportPath);
    	this.dataList = dataList;
	}
    
    public void createReport() throws Exception{
    	logger.info("Creating " + sourceReportPath.getFileName().toString());
    	int batchId = 1;
//    	int MAX_BATCHES = 1;
//    	int BATCH_SIZE = (this.dataList.size()/MAX_BATCHES)+1;
//    	int MAX_BATCHES = 1;
    	int BATCH_SIZE = 10000;
//    	String reportName = sourceReportPath.getFileName().toString();
    	int i = 0;
    	while (i < this.dataList.size()){
//    	//for (int i = 1; i < this.dataList.size()-1+BATCH_SIZE; i+=BATCH_SIZE) {
//    		sourceReportPath = sourceReportPath.resolveSibling((batchId++)+"_"+reportName);
			createReport(i, i+BATCH_SIZE);
			i+=BATCH_SIZE;
			//if (i > 15) break;
		}
    	
        logger.info("Report has been created: " + sourceReportPath.normalize().toAbsolutePath());
	}
    public void createReport(int startRow, int endRow) throws Exception{
    	logger.info(String.format("Creating %s", sourceReportPath.getFileName().toString() ));
    	
    	//Open Workbook
    	openWorkbook(sourceReportPath);
    	
    	//Data Sheet 
    	buildDataSheet(startRow, endRow);

    	//Details Sheet 
    	//buildDocDetails();
    	
    	// Write the output to a file
    	saveReport();
    	
    	logger.info(String.format("Report has been created %s ", sourceReportPath.toAbsolutePath()));
    }
    
	private void buildDataSheet(int startRow, int endRow) throws Exception {
		int from = (int)(((float)startRow/(float)this.dataList.size())*100);
		int to = (int)(((float)Math.min(endRow, this.dataList.size())/(float)this.dataList.size())*100);
		logger.info("Building Datasheet ["+from+"% - "+to+"%]");
		int rowInd;
		char colInd, colAreaInd;
		Sheet sheet = getSheet(Sheets.Data);
		String tableName;
		String startCell;
		String endCell;
		String endColumn;
		int areaCount, areaTotalCount, topAreaCount;
		String topArea;
		double areaCountPercent, topAreaPercent;
		
		CellStyle csDate = getDateFormat("yyyy/MM/dd");
		CellStyle csTime = getDateFormat("dd/MM/yyyy hh:mm:ss");
		CellStyle csNumber = getDateFormat("#,##0");
		CellStyle percentStyle = getNumberFormat("0%");
		
		
//		tableName = "Table2567910";
//		startCell = getTableStartCellReference(sheet, tableName);
//		endCell = getTableLastColumn(sheet, tableName)+(this.dataList.size()+1);
//		endColumn = endCell.replaceAll("\\d+", ""); 
//		rowInd = getTableFirstDataRow(sheet, tableName);
		
//		boolean isFirstRow = (startRow==0);
//
//		if (isFirstRow && this.dataList.size()>0){
//			resizeTable(sheet, tableName, startCell, endCell);
//			unhideSheet(sheet.getSheetName());
//		}
//		
		
		Object[] dto;
		int i = 0 + startRow;
		rowInd = 2 + startRow;

		//for (; i < endRow && i < dataList.size(); ) {
		for (; i < dataList.size(); ) {
		//for (String  row : this.dataList) {
		
			dto = this.dataList.get(i++);
			
			colInd='A';
			
			for (Object obj : dto) {
				setCell(sheet, rowInd, colInd++, (String)obj);
			}

			//Id.
			//setCell(sheet, rowInd, colInd++, Integer.valueOf(tokens[tokenIndex++]));
			//setCell(sheet, rowInd, colInd++, DateUtils.parseDate(tokens[tokenIndex++], new String[]{"yyyy-MM-dd"}), csDate);
			//Time
			rowInd++;
        }
	}
	

	public static void main(String[] args) throws Exception {
		List<Object[]> objs = new ArrayList<>(Arrays.asList(
				  new Object[]{"1", "one"}
				, new Object[]{"2", "two"}
				, new Object[]{"3", "three"}
				, new Object[]{"4", "four"}
				)); 
		
		Path masterReportPath = Paths.get(ObjectArrayXLSXWriter.DEFAULT_REPORT); 
		Path outputReportPath = masterReportPath.resolveSibling(TimeUtils.getTimestamp()+".xlsx"); 
		ObjectArrayXLSXWriter writer = new ObjectArrayXLSXWriter(objs, outputReportPath, masterReportPath);
		
		writer.createReport();
	}


}
