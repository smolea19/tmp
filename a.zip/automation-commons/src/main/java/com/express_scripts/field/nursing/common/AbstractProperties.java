package com.express_scripts.field.nursing.common;

import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.common.files.properties.FilesLastUpdateCalculator;



public abstract class AbstractProperties {

	private static final Logger LOG = LogManager.getLogger(AbstractProperties.class);
	
	
	/**
	 * Handles files, jar entries, and deployed jar entries in a zip file (EAR).
	 * @return The date if it can be determined, or null if not.
	 */
	protected static String getClassBuildTime(Class<?> currentClass) {
		return FilesLastUpdateCalculator.getClassBuildTime(currentClass);
	   
	}
	public static String getVersion(String version, final ResourceBundle RESOURCE_BUNDLE) {
		return version + " " + getProperty("version", RESOURCE_BUNDLE);
	}
	public static long getLongProperty(String key, final ResourceBundle RESOURCE_BUNDLE) {
		String value = getProperty(key, RESOURCE_BUNDLE);
		return Long.parseLong(value);
	}

	public static char[] getCharArrayProperty(String key, final ResourceBundle RESOURCE_BUNDLE) {
		return getProperty(key, RESOURCE_BUNDLE).toCharArray();
	}

	protected static String getProperty(String key, final ResourceBundle RESOURCE_BUNDLE) {
		if (RESOURCE_BUNDLE == null){
			String error = "Initilize RESOURCE_BUNDLE by calling getVersion()";
			LOG.fatal(error);
		}
		String value = RESOURCE_BUNDLE.getString(key);
		
		LOG.trace(String.format("{%s, %s}", key, value));
		return value;
	}

	

	
}
