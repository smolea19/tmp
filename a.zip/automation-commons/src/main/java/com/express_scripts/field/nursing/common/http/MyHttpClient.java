package com.express_scripts.field.nursing.common.http;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class MyHttpClient {

	private static final Logger LOG = LogManager.getLogger(MyHttpClient.class);

	private static final String USER_AGENT = "Mozilla/5.0";


	// HTTP GET request
	
	public String sendGetAsStr(String url, List<NameValuePair>headers) throws Exception {
		return sendGetAsStr(url, headers, new Integer[]{HttpStatus.SC_OK});
	}
	public String sendGetAsStr(String url, List<NameValuePair>headers, Integer[] expectedStatusCodes) throws Exception {
		HttpResponse response = sendGet(url, headers, expectedStatusCodes);
		
		BufferedReader buffReader = new BufferedReader(
                new InputStreamReader(response.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = buffReader.readLine()) != null) {
			result.append(line);
		}

		return result.toString();
	}
	public HttpResponse sendGet(String url) throws Exception {
		return sendGet(url, new ArrayList<NameValuePair>());
	}

	public HttpResponse sendGet(String url, List<NameValuePair>headers) throws Exception {
		return sendGet(url, headers, new Integer[] {HttpStatus.SC_OK});
	}
	public HttpResponse sendGet(String url, List<NameValuePair>headers, Integer[] expectedHttpStatusCodes) throws Exception {
		HttpGet request = new HttpGet(url);
		
		HttpClient client = new DefaultHttpClient();
		// add request header
		request.addHeader("User-Agent", USER_AGENT);

		for (NameValuePair nameValuePair : headers) {
			request.addHeader(nameValuePair.getName(), nameValuePair.getValue());
		}
		
		 

		HttpResponse response = client.execute(request);

		LOG.debug("Response Code : " + response.getStatusLine().getStatusCode());

		boolean isExpectedHttpCode = isExpectedHttpCode(response.getStatusLine().getStatusCode(), expectedHttpStatusCodes);
		if (!isExpectedHttpCode){
			throw new Exception("Unable to execute GET Response Code: " + url + "\n Found " + response.getStatusLine().getStatusCode() + " Expected " + new ArrayList<Integer>(Arrays.asList(expectedHttpStatusCodes)));
		}
		
		return response;

	}

	private boolean isExpectedHttpCode(int statusCode, Integer[] expectedHttpStatusCodes) {
		for (int i = 0; i < expectedHttpStatusCodes.length; i++) {
			if (expectedHttpStatusCodes[i] == statusCode){
				return true;
			}
		}
		return false;
	}
	// HTTP POST request
	public HttpResponse sendPost(String url, List<NameValuePair>urlParameters) throws Exception {
		return sendPost(url, urlParameters, HttpStatus.SC_OK);
	}
	public HttpResponse sendPost(String url, List<NameValuePair>urlParameters, int expectedHttpStatusCode) throws Exception {

		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);

		
		// add header
		post.setHeader("User-Agent", USER_AGENT);

		post.setEntity(new UrlEncodedFormEntity(urlParameters));

		LOG.debug("\nSending 'POST' request to URL : " + url);
		HttpResponse response = client.execute(post);
		
		if (response.getStatusLine().getStatusCode() != expectedHttpStatusCode){
			throw new Exception("["+response.getStatusLine().getStatusCode()+"]Unexpected POST response. Expected "+expectedHttpStatusCode+" Response Code: " + url + "\n");
		}
		
		return response;
	}
	public HttpResponse sendPost(String url, List<NameValuePair>headers, String payload) throws Exception {
		return sendPost(url, headers, payload, HttpStatus.SC_OK);
	}
	public HttpResponse sendPost(String url, List<NameValuePair>headers, String payload, int expectedResponse) throws Exception {
		
		HttpClient client = new DefaultHttpClient();
		HttpPost put = new HttpPost(url);
		
		
		// add header
		put.setHeader("User-Agent", USER_AGENT);
		for (NameValuePair header : headers) {
			put.addHeader(header.getName(), header.getValue());

			LOG.trace(header.getName()+"="+header.getValue());
		}

		if (payload != null){
			put.setEntity(new StringEntity(payload,  "UTF-8"));
		}
		
		LOG.trace("\nSending 'POST' request to URL : " + url);
		LOG.trace("\nHeaders : " + headers);
		LOG.trace("\nPayload : " + payload);
		HttpResponse response = client.execute(put);
		
		if (response.getStatusLine().getStatusCode() != expectedResponse){
			throw new Exception("Unable to execute PUT 200 Response Code: " + url + "\n" 
					+ "\n" + response.getStatusLine().getStatusCode()
					+ "\n" + response.getStatusLine().getReasonPhrase());
		}

		return response;
	}
	public HttpResponse sendPatch(String url, List<NameValuePair>headers, String payload, int expectedResponse) throws Exception {
		
		HttpClient client = new DefaultHttpClient();
		HttpPatch patch = new HttpPatch(url);
		
		
		// add header
		patch.setHeader("User-Agent", USER_AGENT);
		for (NameValuePair header : headers) {
			patch.addHeader(header.getName(), header.getValue());
			
			LOG.trace(header.getName()+"="+header.getValue());
		}
		
		patch.setEntity(new StringEntity(payload,  "UTF-8"));
		
		LOG.trace("\nSending 'PATCH' request to URL : " + url);
		LOG.trace("\nHeaders : " + headers);
		LOG.trace("\nPayload : " + payload);
		HttpResponse response = client.execute(patch);
		
		if (response.getStatusLine().getStatusCode() != expectedResponse){
			throw new Exception("Unable to execute PATCH "+expectedResponse+" Response Code: " + url + "\n" 
					+ "\n" + response.getStatusLine().getStatusCode()
					+ "\n" + response.getStatusLine().getReasonPhrase()
					+ "\n" + extractResponse(response)
					);
		}
		
		return response;
	}
	public HttpResponse sendDelete(String url, List<NameValuePair>headers, int expectedResponse) throws Exception {
		
		HttpClient client = new DefaultHttpClient();
		HttpDelete delete = new HttpDelete(url);
		
		
		// add header
		delete.setHeader("User-Agent", USER_AGENT);
		for (NameValuePair header : headers) {
			delete.addHeader(header.getName(), header.getValue());
			
			LOG.trace(header.getName()+"="+header.getValue());
		}
		//delete.setEntity(new StringEntity("{}",  "UTF-8"));
		
		LOG.trace("\nSending 'DELETE' request to URL : " + url);
		LOG.trace("\nHeaders : " + headers);
		HttpResponse response = client.execute(delete);
		
		if (response.getStatusLine().getStatusCode() != expectedResponse){
			throw new Exception("Unable to execute DELETE "+expectedResponse+" Response Code: " + url + "\n" 
					+ "\n" + response.getStatusLine().getStatusCode()
					//+ "\n" + response.getStatusLine().getReasonPhrase()
					//+ "\n" + extractResponse(response)
					);
		}
		
		return response;
	}

	public HttpResponse sendPut(String url, List<NameValuePair>headers, String payload) throws Exception {
		
		HttpClient client = new DefaultHttpClient();
		HttpPut put = new HttpPut(url);
		
		
		// add header
		put.setHeader("User-Agent", USER_AGENT);
		for (NameValuePair header : headers) {
			put.addHeader(header.getName(), header.getValue());
		}
		
		put.setEntity(new StringEntity(payload,  "UTF-8"));
		
		//LOG.info("\nSending 'POST' request to URL : " + url);
		HttpResponse response = client.execute(put);
		
		if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK){
			LOG.error(response);
			throw new Exception("Unable to execute PUT 200 Response Code: " + response.getStatusLine().getStatusCode());
		}
		
		
		return response;
	}
	
	public static String extractCookie(HttpResponse response, String name, String valueToken)
	{
		Header[] headers = response.getAllHeaders();
		String value = "";
		for (int i = 0; i < headers.length; i++) {
			if (name.equals(headers[i].getName()) && headers[i].getValue().contains(valueToken)){
				value = headers[i].getValue();
			}
		}

		return value;
	}
	public static int extractResponseStatus(HttpResponse response){
		return response.getStatusLine().getStatusCode();
	}
	public static String extractResponse(HttpResponse httpResponse) throws Exception {
		String jsonString = EntityUtils.toString(httpResponse.getEntity(), Charset.forName("UTF-16"));
		
		return jsonString;
	}
}
