package com.express_scripts.field.nursing.common.files.excel.writer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTable;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.impl.CTTableImpl;

import com.express_scripts.field.nursing.common.files.excel.BaseXLS;

public abstract class BaseReport extends BaseXLS {
	private final static Logger logger = Logger.getLogger(BaseReport.class);
	
	protected static boolean isPrintAsLocked = false;
	protected Font lockedCellFont;
	protected CellStyle lockedCellStyle = null;
	
	
	

	
	static {
		CellStyle CELL_STYLE_RED;
	}

	private Workbook wb;
	private OPCPackage pkg;
	private final Path masterReportPath;
	private CreationHelper creationHelper;
	private Font boldFont;
	private Font redFont;
	
	
	
	public BaseReport(Path reportPath, Path masterReportPath) {
		super(reportPath);
		this.masterReportPath = masterReportPath;
	}

	protected CellStyle getNumberFormat(String pattern) throws Exception {
		DataFormat df = this.wb.createDataFormat();
		CellStyle cs = this.wb.createCellStyle();  
		cs.setDataFormat(df.getFormat(pattern));
		
		return cs;
	}
	protected CellStyle getHighlightFormat(IndexedColors indexedColor) throws Exception {
		CellStyle cs = this.wb.createCellStyle();  
		cs.setFillForegroundColor(indexedColor.getIndex());
		//cs.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 0, 0)).getIndexed());
		cs.setFillPattern(CellStyle.SOLID_FOREGROUND);
		
		return cs;
	}
	protected CellStyle getHighlightFormatGreen() throws Exception {
		return getHighlightFormat(198, 239, 206, 0,  97,  94);
	}
	protected CellStyle getHighlightFormatRed() throws Exception {
		return getHighlightFormat(255, 199, 206, 156, 0, 58);
	}
	protected CellStyle getHighlightFormatGray() throws Exception {
		CellStyle cs = this.wb.createCellStyle();  
		
		XSSFCellStyle style = ((XSSFCellStyle)cs);

		XSSFFont font = getLockedStyleFont();
        style.setFont(font);
        return style;
		//return getHighlightFormat(255, 255, 255, 128, 128, 128);
	}
	protected XSSFFont getLockedStyleFont(){
		XSSFFont font = null;
		try {
			font = (XSSFFont)this.wb.createFont();
			XSSFColor myFontColor = new XSSFColor(new java.awt.Color(128, 128, 128));
			font.setColor(myFontColor);
			
		} catch (Exception e) {
			logger.fatal("Unable to create Locked Style format", e);
		}

		
		
		return font;
	}
	protected CellStyle getHighlightFormatLightGreen() throws Exception {
		return getHighlightFormat(234, 241, 221, 0, 0, 0);
	}
	protected CellStyle getHighlightFormatBolds() throws Exception {
		CellStyle cs = this.wb.createCellStyle();  
		XSSFCellStyle style = ((XSSFCellStyle)cs);
		
		XSSFFont font = (XSSFFont)this.wb.createFont();
        font.setBold(true);
        style.setFont(font);
		
		return style;
	}
	protected CellStyle getDecimalFormat(String format) throws Exception {
		CellStyle cs = this.wb.createCellStyle();  
		XSSFCellStyle style = ((XSSFCellStyle)cs);
		
		DataFormat dataFormat = this.wb.getCreationHelper().createDataFormat();
		
		style.setDataFormat(dataFormat.getFormat(format));
		
		return style;
	}
	protected CellStyle getHighlightFormatYellow() throws Exception {
		return getHighlightFormat(255, 235, 156, 156, 101, 0);
	}
	protected CellStyle getHighlightFormat(int bgr, int bgg, int bgb) throws Exception {
		CellStyle cs = this.wb.createCellStyle();  
		
		XSSFCellStyle style = ((XSSFCellStyle)cs);
		XSSFColor myColor = new XSSFColor(new java.awt.Color(bgr, bgg, bgb));
		style.setFillForegroundColor(myColor);
		
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		
		return style;
	}
	protected CellStyle getHighlightFormat(int bgr, int bgg, int bgb, int fontr, int fontg, int fontb) throws Exception {
		CellStyle cs = this.wb.createCellStyle();  
		
		XSSFCellStyle style = ((XSSFCellStyle)cs);
		XSSFColor myColor = new XSSFColor(new java.awt.Color(bgr, bgg, bgb));
		style.setFillForegroundColor(myColor);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		
		XSSFFont font = (XSSFFont)this.wb.createFont();
		XSSFColor myFontColor = new XSSFColor(new java.awt.Color(fontr, fontg, fontb));
        font.setColor(myFontColor);
        style.setFont(font);
		
		return style;
	}
	protected CellStyle getDateFormat(String pattern) throws Exception {
		DataFormat df = this.wb.createDataFormat();
		CellStyle cs = this.wb.createCellStyle();  
		cs.setDataFormat(df.getFormat(pattern));
		
		return cs;

	}
	protected void openWorkbook(Path reportPath) throws Exception {
		logger.info("Opening workbook: " + reportPath);
		this.sourceReportPath = reportPath;
		if (!reportPath.toFile().exists()){
			createReport(reportPath);
		}
		
		try (FileInputStream fis = new FileInputStream(reportPath.toFile())){
			logger.info("Opening Filestream: " + reportPath);
			//this.pkg = OPCPackage.open(fis);
			//this.wb = new XSSFWorkbook(this.pkg);
	
			this.wb = new XSSFWorkbook(fis);
		}
	}
	
	protected Sheet getSheet(String sheetName) {
		Sheet sheet = this.wb.getSheet(sheetName);
		unhideSheet(sheetName);
		return sheet;
	}

	protected void unhideSheet(String sheetName) {
		this.wb.setSheetHidden(this.wb.getSheetIndex(sheetName), 0);
	}
	protected void hideSheet(String sheetName) {
		this.wb.setSheetHidden(this.wb.getSheetIndex(sheetName), 1);
	}

	
	private Path createReport(Path dest) throws Exception {
		
		Path source = this.masterReportPath;
		logger.info(String.format("Creating new file from %s into %s", this.masterReportPath, dest));
		Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
		
		return dest;
	}

	
	protected void saveReport()
			throws FileNotFoundException, IOException {
		logger.info("Saving Report - " + this.sourceReportPath.getFileName());
		try (FileOutputStream out = new FileOutputStream(this.sourceReportPath.toFile());){
			this.wb.write(out);
		}
	}

	/**
	 * Resolves 
	 *    a/b/c/myFile.txt
	 * to 
	 *    a/b/c/myFile_suffix.txt
	 *    
	 * @param source
	 * @param suffix
	 * @return
	 */
	protected Path resolveSibling(Path source, String suffix){
		StringBuffer newFileName = new StringBuffer(source.getFileName().toString());
		int extIndex = newFileName.lastIndexOf(".");
		newFileName.insert(extIndex, suffix);
		
		Path siblingPath = source.resolveSibling(newFileName.toString());

		return siblingPath;
	}
	
	private XSSFTable getTable(Sheet sheet, String tableName){
		List<XSSFTable> tables =((XSSFSheet)sheet).getTables();
		XSSFTable table = null;
		for (XSSFTable xssfTable : tables) {
			if (xssfTable.getName().equals(tableName)){
				table = xssfTable;
				break;
			}
		}
		
		return table;
	}
	protected void resizeTable(Sheet sheet, String tableName, String startCell, String endCell){
		XSSFTable table = getTable(sheet, tableName);
		if (table!=null){
			CTTableImpl  ct = 	(CTTableImpl)table.getCTTable();
			ct.setRef(startCell+":"+endCell);
		}
	}
	
	protected String getTableStartCellReference(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String cell = String.format("%s%s"
				, table.getStartCellReference().getCellRefParts()[2]
				, table.getStartCellReference().getCellRefParts()[1]);
		return cell;
	}

	protected String getTableEndCellReference(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String cell = String.format("%s%s"
				, table.getEndCellReference().getCellRefParts()[2]
				, table.getEndCellReference().getCellRefParts()[1]);
		return cell;
	}

	protected String getTableLastColumn(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String column = table.getEndCellReference().getCellRefParts()[2];
		return column;
	}

	protected int getTableFirstDataRow(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		int row = Integer.parseInt(table.getStartCellReference().getCellRefParts()[1])+1;
		return row;
	}
	protected int getTableLastDataRow(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		int row = Integer.parseInt(table.getEndCellReference().getCellRefParts()[1])+1;
		return row;
	}
	

	protected Cell getCell(Sheet sheet, int rowInd, char colInd){
		Row row = sheet.getRow(row(rowInd));
		if (row == null){
			row = sheet.createRow(row(rowInd));
		}
    	Cell cell = row.getCell(col(colInd));
    	if (cell == null){
    		cell = row.createCell(col(colInd));
    	}
    	return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, String value){
		Cell cell = getCell(sheet, rowInd, colInd);
		//cell.setCellValue(paramRichTextString)
		cell.setCellValue(value==null?"":value.trim());
		
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	
	public void printCellAsLockedIfEnabled(Cell cell){
		if (isPrintAsLocked){
			if (lockedCellStyle == null){
				CellStyle oldStyle = cell.getCellStyle();
				CellStyle newStyle = this.wb.createCellStyle();
				newStyle.cloneStyleFrom(oldStyle);
				XSSFFont font = getLockedStyleFont();
				newStyle.setFont(font);
				newStyle.setFillPattern(CellStyle.NO_FILL);
				
				lockedCellStyle = newStyle;
			}
			 cell.setCellStyle(lockedCellStyle);
			 
			//cell.getCellStyle().cloneStyleFrom(paramCellStyle)
			//cell.getCellStyle().setFont(this.lockedCellFont);
			//CellUtil.setCellStyleProperty(cell, this.wb, CellUtil.FILL_BACKGROUND_COLOR,new org.apache.poi.hssf.util.HSSFColor.BLUE_GREY().getHexString());
		}
	}
	protected Cell setCell(Sheet sheet, int rowInd, char colInd, String value, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		//cell.setCellValue(paramRichTextString)
		cell.setCellValue(value==null?"":value.trim());
		cell.setCellStyle(cellStyle);
		
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	protected void setFontColor(Sheet sheet, int rowInd, char colInd, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellStyle(cellStyle);
		//CellStyle cellStyle = 
		//Short color = 50;
		//cellStyle.setFillForegroundColor(color);

	}
	

	
	protected void highlightCell(Sheet sheet, int rowInd, char colIndStart,
			int colIndEnd, CellStyle highlightFormat) {
		Cell cell;
		for (char colInd = colIndStart; colInd < colIndEnd; colInd++) {
			cell = getCell(sheet, rowInd, colInd);
			cell.setCellStyle(highlightFormat);
			
			printCellAsLockedIfEnabled(cell);
		}

		
	}
	protected void addCellComments(Sheet sheet, int rowInd, char colInd, String comments) {
		Cell cell = getCell(sheet, rowInd, colInd);
		RichTextString str;
		String author;
		Comment comment = buildComment(sheet, cell, comments, "Apache POI");
		cell.setCellComment(comment);
	}
	
	private Comment buildComment(Sheet sheet, Cell cell, String text, String author){
		RichTextString previousComment, newComment;
		 CreationHelper factory = this.wb.getCreationHelper();
		 
		Drawing drawing = sheet.createDrawingPatriarch();
		
		 // When the comment box is visible, have it show in a 1x3 space
	    ClientAnchor anchor = factory.createClientAnchor();
	    
	    anchor.setCol1(cell.getColumnIndex());
	    anchor.setCol2(cell.getColumnIndex()+2);
	    anchor.setRow1(cell.getRow().getRowNum());
	    anchor.setRow2(cell.getRow().getRowNum()+5);
		
		  // Create the comment and set the text+author
	    Comment comment = drawing.createCellComment(anchor);
	    previousComment = comment.getString();
	    boolean hasPreviousComment = (previousComment!= null && !StringUtils.isEmpty(previousComment.getString())); 
	    if (hasPreviousComment){
	    	text = previousComment.getString() + " - "+ text;
	    }
	    newComment = factory.createRichTextString(text);

	    comment.setString(newComment);
	    comment.setAuthor(author);
	    
	    return comment;
	}

	
	protected Cell setCellNumeric(Sheet sheet, int rowInd, char colInd, String value, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		
		if (StringUtils.isNotBlank(value)){
			cell.setCellValue(Double.parseDouble(value.trim()));
		}
		if (cellStyle != null){
			cell.setCellStyle(cellStyle);
		}
		
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	protected Cell setCellNoTrim(Sheet sheet, int rowInd, char colInd, String value){
		Cell cell = getCell(sheet, rowInd, colInd);
		//cell.setCellValue(paramRichTextString)
		cell.setCellValue(value==null?"":value.trim());
		
		printCellAsLockedIfEnabled(cell);
		return cell;
	}

	protected Cell setCellWithBolds(Sheet sheet, int rowInd, char colInd, String value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(formatValue(value));
		
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	
	private RichTextString formatValue (String value){
		if (value == null){
			return new XSSFRichTextString("");
		}
		RichTextString richTextString = new XSSFRichTextString(value.trim());
		applyFont(boldFont, richTextString, "Calculation:");
		applyFont(boldFont, richTextString, "Current Values:");
		applyFont(boldFont, richTextString, "eForm field:");
		applyFont(boldFont, richTextString, "eForm fields:");
		applyFont(boldFont, richTextString, "Required Rule indicated by:");
		applyFont(boldFont, richTextString, "Field      :");
		applyFont(boldFont, richTextString, "Expected   :");
		applyFont(boldFont, richTextString, "Actual     :");
		applyFont(boldFont, richTextString, "eForm cell :");
		applyFont(boldFont, richTextString, "JSON  :");
		applyFont(boldFont, richTextString, "eForm :");
		applyFont(boldFont, richTextString, "JSON:");
		
		applyFont(redFont, richTextString, "NOT FOUND");
		
		return richTextString;
	}
	
	private void applyFont(Font font, RichTextString richTextString, String value) {
		int startIndex = richTextString.getString().indexOf(value); 
		int endIndex = startIndex + value.length();
		
		if (startIndex>=0){
			richTextString.applyFont(startIndex, endIndex, font);
		}
	}

	
	protected Cell setCellFormula(Sheet sheet, int rowInd, char colInd, String formula){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellFormula(formula);
		return cell;
	}
	protected String getCellFormula(Sheet sheet, int rowInd, char colInd){
		Cell cell = getCell(sheet, rowInd, colInd);
		return cell.getCellFormula();
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, Date value, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		cell.setCellStyle(cellStyle);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, int value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	protected Cell setCell(Sheet sheet, int rowInd, char colInd, double value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	protected Cell setCell(Sheet sheet, int rowInd, char colInd, double value, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		cell.setCellStyle(cellStyle);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}
	protected Cell setDecimalCell(Sheet sheet, int rowInd, char colInd, float value, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		cell.setCellStyle(cellStyle);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, Long value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}

	protected Cell setCellComment(Sheet sheet, int rowInd, char colInd, String commentValue){
		Cell cell = getCell(sheet, rowInd, colInd);
		
		Drawing drawing = sheet.createDrawingPatriarch();
		ClientAnchor anchor = creationHelper.createClientAnchor();
		Comment comment = drawing.createCellComment(anchor);
	    RichTextString str = creationHelper.createRichTextString(commentValue);
	    comment.setString(str);
	    comment.setAuthor("Sergio Olea");
	    
		cell.setCellComment(comment);
		return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, boolean value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		printCellAsLockedIfEnabled(cell);
		return cell;
	}

}
