package com.express_scripts.field.nursing.common.time;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public final class TimeUtils {

	private static final Logger LOG = LogManager.getLogger(TimeUtils.class);
	
	public static final String FORMAT_YYYYMMddHHmm = "yyyy/MM/dd HH:mm";
	public static final String FORMAT_YYYYMMddHHmmsszzz = "yyyy/MM/dd HH:mm:ss zzz";
	public static final String FORMAT_YYYYMMddHHmmss = "yyyy/MM/dd HH:mm:ss";
	public static final String FORMAT_YYYYMMdd = "yyyy/MM/dd";
	public static final String FORMAT_YYYYMMDD_PLAIN = "yyyyMMdd";

	private TimeUtils() {
		// No call
	}
	public static String getDateAsTimestamp(Date date)
    {
		LOG.trace(date);
		return getDateAsTimestamp(date, FORMAT_YYYYMMDD_PLAIN);
    }
	public static String getDateAsDefaultFormat(Date date)
	{
		LOG.trace(date);
		
		return getDateAsTimestamp(date, FORMAT_YYYYMMddHHmmsszzz);
	}
	public static String getDateAsExcelFormat(Date date)
	{
		LOG.trace(date);
		
		return getDateAsTimestamp(date, FORMAT_YYYYMMddHHmmss);
	}

	public static String getDateAsTimestamp(Date date, String pattern) 
	{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		String dateAsTimestamp = "";
		if(date != null){
			dateAsTimestamp = sdf.format(date); 
		}
		return dateAsTimestamp;
	}
	public static String getDateAsTimestamp(Date date, String pattern, Locale locale) throws Exception
	{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern, locale);
		
		return sdf.format(date);
	}
	
	public static String getToday(String format) throws Exception{
		return getDateAsTimestamp(new Date(), format);
	}
	public static String getToday() throws Exception{
		return getDateAsTimestamp(new Date(), FORMAT_YYYYMMddHHmmsszzz);
	}
	public static Date getTomorrowAsTruncDate(){
		return DateUtils.truncate(getTomorrowAsDate(), Calendar.DATE);
	}
	public static Date getYesterdayAsTruncDate(){
		return DateUtils.truncate(getYesterdayAsDate(), Calendar.DATE);
	}
	public static Date getTomorrowAsDate(){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		return cal.getTime();
	}
	public static Date getYesterdayAsDate(){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}
	public static String getTodayYYYYMMDD() throws Exception{
		return getDateAsTimestamp(new Date(), FORMAT_YYYYMMdd);
	}
	public static Date parseDate(String dateStr, String format) throws ParseException{
		return parseDate(dateStr, format, Locale.getDefault());
	}
	public static String getTimestamp() throws Exception {
		return getDateAsTimestamp(new Date(), "yyyyMMdd_HHmmss");
	}
	public static Date parseDate(String dateStr, String format, Locale locale) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
		
		return sdf.parse(dateStr);
	}
	public static String getNowHHmmss(){
		SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
		
		return sdf.format(new Date());
	}
	public static String getYear(){
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY");
		
		return sdf.format(new Date());
	}
	public static long getTimestampFromTodayTime(String timeStr, String timeFormat) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(timeFormat);
		
		Date aDate = sdf.parse(timeStr);

		Calendar calendar = Calendar.getInstance();
		
		calendar.set(Calendar.HOUR_OF_DAY, aDate.getHours());
		calendar.set(Calendar.MINUTE, aDate.getMinutes());
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		LOG.trace(calendar.getTime());
		
		return calendar.getTimeInMillis() + calendar.get(Calendar.DST_OFFSET);
	}
	public static long getNextDateFromToday(String dateStr, String dateFormat) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		
		Date today = DateUtils.truncate(new Date(), Calendar.DATE);
		Date taskDate = sdf.parse(dateStr);
		taskDate = DateUtils.truncate(taskDate, Calendar.DATE);
		
		Calendar calendar = Calendar.getInstance();
		
		taskDate = DateUtils.setYears(taskDate, calendar.get(Calendar.YEAR));
		
		LOG.trace("taskDate:" + taskDate);
		LOG.trace("now :" + today);
		
		boolean isTaskDateBeforeToday = (DateUtils.truncatedCompareTo(taskDate, today, Calendar.DATE)<0);
		LOG.trace("isTaskDateBeforeToday :" + isTaskDateBeforeToday);
		
		if (isTaskDateBeforeToday){
			taskDate = DateUtils.setYears(taskDate, calendar.get(Calendar.YEAR)+1);
		}
		taskDate = DateUtils.setHours(taskDate, 0);
		taskDate = DateUtils.setMinutes(taskDate, 0);
		taskDate = DateUtils.setSeconds(taskDate, 0);
		taskDate = DateUtils.setMilliseconds(taskDate, 0);
		
	
		LOG.trace(taskDate.getTime());
		
		return taskDate.getTime() + calendar.get(Calendar.DST_OFFSET);
	}
	
	public static void main(String[] args) throws ParseException {
		//LOG.info(getTomorrowAsTruncDate());
		
		getPreviousMonday(DateUtils.parseDate("2017/09/24", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/09/25", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/09/26", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/09/27", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/09/28", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/09/29", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/09/30", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/10/01", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/10/02", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/10/03", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/10/04", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/10/05", "yyyy/MM/dd"));
		getPreviousMonday(DateUtils.parseDate("2017/10/06", "yyyy/MM/dd"));
		
		/*
		getPreviousSunday(DateUtils.parseDate("2017/09/24", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/09/25", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/09/26", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/09/27", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/09/28", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/09/29", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/09/30", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/10/01", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/10/02", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/10/03", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/10/04", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/10/05", "yyyy/MM/dd"));
		getPreviousSunday(DateUtils.parseDate("2017/10/06", "yyyy/MM/dd"));
*/
	}
	public static Date getPreviousSunday(Date reviewDate) {
		Calendar cal=DateUtils.toCalendar(reviewDate);
		cal.add( Calendar.DAY_OF_WEEK, -(cal.get(Calendar.DAY_OF_WEEK)-1)); 
		Date dateSunday = cal.getTime();

		LOG.debug(reviewDate + "-->" + dateSunday);
		return dateSunday;
	}
	public static Date getPreviousMonday(Date reviewDate) {
		Calendar cal=DateUtils.toCalendar(reviewDate);
		
		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		
		if (dayOfWeek == Calendar.SUNDAY){
			dayOfWeek = 8;
		}
		
		cal.add( Calendar.DAY_OF_WEEK, -(dayOfWeek-2)); 
		Date dateMonday = cal.getTime();
		
		LOG.debug(reviewDate + "-->" + dateMonday);
		
		return dateMonday;
	}
}
