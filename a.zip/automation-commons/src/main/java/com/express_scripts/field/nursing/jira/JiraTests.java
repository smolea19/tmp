package com.express_scripts.field.nursing.jira;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.jsoup.examples.HtmlToPlainText;
import org.jsoup.nodes.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.express_scripts.field.nursing.common.files.excel.writer.ObjectArrayXLSXWriter;
import com.express_scripts.field.nursing.common.files.text.TextFileUtils;
import com.express_scripts.field.nursing.common.http.HTTPClient;
import com.express_scripts.field.nursing.common.time.TimeUtils;

public class JiraTests {
	
	private static final Logger LOG = LogManager.getLogger(JiraTests.class);
	
	WebDriver driver;
	
	private String baseUrl = "https://jira.express-scripts.com";
	
	
	
	public JiraTests() {
		super();
		System.out.println("Setting up environment.. ");

		driver = new FirefoxDriver();
	}

	private WebElement sendKeys(By by, String text){
		WebElement webElement = driver.findElement(by);
		webElement.sendKeys(text);
		return webElement;
	}

	private WebElement click(By by){
		WebElement webElement = driver.findElement(by);
		webElement.click();
		return webElement;
	}

	
	public void extractUserStoriesDetails() throws Exception {
		
		
		//driver.manage().window().maximize();
		
		System.out.println("Logging in.. ");
		//driver.navigate().to(baseUrl+"/login.jsp");
		driver.get(baseUrl+"/login.jsp");
		
		sendKeys(By.id("login-form-username"), "seolea");
		sendKeys(By.id("login-form-password"), "Mpoc_00020");
		click(By.id("login-form-remember-me"));
		click(By.id("login-form-submit"));
		
		System.out.println("Authenticating...");
		
		List<Object[]> objList = new ArrayList<>();
		
		List<String> userStories=new ArrayList<>(Arrays.asList(
				"SPFFN-1106"
				, "SPFFN-1211"
				, "SPFFN-1210"
				));
		
		Collections.sort(userStories);
		
		String[][] metadataArray = new String[][]{
				  {"User Story Id", "//div[@class='aui-page-header-main']//a[@class='issue-link']"}
				, {"User Story Description", "//div[@class='aui-page-header-main']//h1[@id='summary-val']"}
				, {"Description", "//div[@id='descriptionmodule']//p"}
				, {"Acceptance Criteria", "//strong[@title='Acceptance Criteria']/..//div"}
				, {"Assignee", "//*[@id='assignee-val']"}
				, {"Story Points", "//strong[@title='Story Points']/..//div"}
				, {"Sprint", "//strong[@title='Sprint']/..//div"}
				, {"Fix Version/s:", "//*[@id='fixfor-val']"}
				, {"Application Component", "//strong[@title='Application Component']/..//div"}
				, {"Epic Link", "//strong[@title='Epic Link']/..//div"}
		};
		
		
		
		objList.add(extractColumnNames(metadataArray));
		
		for (String userStory : userStories) {
			objList.add(extractUserStoryData(userStory, metadataArray));
			System.out.println(">>> ");
		}
		
		System.out.println("Writing Excel");
		
		writeReport(objList);
		
		
		System.out.println("Done!");
		
		
		
	}

	private Object[] extractColumnNames(String[][] metadataArray) {
		Object[] obj = new Object[metadataArray.length];
		int i=0;
		String fieldName;
		for (String[] metadata : metadataArray) {
			fieldName = metadata[0];
			obj[i++] = fieldName;
		}
		
		return obj;
	}

	private void writeReport(List<Object[]> objList) throws Exception {
		Path masterReportPath = Paths.get(ObjectArrayXLSXWriter.DEFAULT_REPORT); 
		Path outputReportPath = masterReportPath.resolveSibling(TimeUtils.getTimestamp()+".xlsx"); 
		ObjectArrayXLSXWriter writer = new ObjectArrayXLSXWriter(objList, outputReportPath, masterReportPath);
		
		writer.createReport();

		
	}

	private Object[] extractUserStoryData(String userStory, String[][] metadataArray) {
		System.out.println("Navigating to user story "+userStory+"... ");
		driver.navigate().to(baseUrl+"/browse/"+userStory);
		
		//WebElement webElement = driver.findElement(By.xpath("//div[@id='customfield_11800-val']/span"));

		
		Object[] obj = new Object[metadataArray.length];
		int i=0;
		String fieldName;
		String fieldValue;
		String fieldXPath;

		for (String[] metadata : metadataArray) {
			fieldName  = metadata[0];
			fieldXPath = metadata[1];
			fieldValue = readField(fieldName, By.xpath(fieldXPath));
			
			obj[i++] = cleanUp(fieldName, fieldValue);
			
		}
		
		return obj;
		
		
	}
	
	private String cleanUp(String fieldName, String fieldValue) {
		String cleanfieldValue = fieldValue;
		switch (fieldName) {
		case "User Story Description":
			cleanfieldValue = removeLineBreaks(fieldValue);
			
			break;
		case "Acceptance Criteria":
			cleanfieldValue = removeShowHide(fieldValue);
			
			break;

		default:
			break;
		}
		
		return cleanfieldValue;
	}
	private String removeLineBreaks(String fieldValue) {
		return fieldValue.replaceAll("\\n", " ");
	}


	private String removeShowHide(String fieldValue) {
		return fieldValue.replaceAll("(?s)Hide <>.*?Show <>\\s*", "");
	}

	private String readField(String fieldName, By xpath){
		String innerHTMLPlainText = getInnerHTMLAsPlainText(xpath);
		
		LOG.info(">>> "+fieldName + ":\t" + innerHTMLPlainText);
		
		return innerHTMLPlainText;
	}
	
	private WebElement getWebElement(By xpath) {
		WebElement webElement = null;

		webElement = driver.findElement(xpath);

		return webElement;
	}

	private String getTextFromField(By xpath) {
		String textHtml;
		try {
			WebElement webElement = getWebElement(xpath);
			textHtml = getWebElement(xpath).getText();
		} catch (NoSuchElementException e) {
			textHtml = "NoSuchElementException";
		}

		return textHtml;
	}

	private String getInnerHtmlFromField(By xpath) {
		String textHtml;
		try {
			WebElement webElement = getWebElement(xpath);
			textHtml = getWebElement(xpath).getAttribute("innerHTML");
		} catch (NoSuchElementException e) {
			textHtml = "NoSuchElementException";
		}
		
		return textHtml;
	}
	
	private String getInnerHTMLAsPlainText(By xpath){
		HtmlToPlainText htmlToPlainText = new HtmlToPlainText();
		
		Element element = new Element("</x>");
		//element = element.append(getTextFromField(xpath));
		element = element.append(getInnerHtmlFromField(xpath));
		String plainText = htmlToPlainText.getPlainText(element).trim();
		
		//System.out.println("plainText: " + plainText);

		return plainText;
	}
	
	private void sendFutureVisitAppReqPostDataTest() throws Exception{
		Path srcFile = Paths.get("etc\\htmlRequests\\FutureVisitAppReqPostData\\SampleRequestTemplate.xml");
		String payload = TextFileUtils.fileToString(srcFile);
		
		String endUrl = "http://CH3DW021670.accounts.root.corp/AccessPoint//webservices/NSFutureVisitAppReq.svc/FutureVisitAppReqPostData";
		
		HTTPClient httpClient = new HTTPClient();
		
		httpClient.makePostRequest(endUrl, payload);

	}

	public static void main(String[] args) throws Exception  {
		new JiraTests().extractUserStoriesDetails();
		
		
		//new JiraTests().sendFutureVisitAppReqPostDataTest();
		System.out.println("end");
	}
}
