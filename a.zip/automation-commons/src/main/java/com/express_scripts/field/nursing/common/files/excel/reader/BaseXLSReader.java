package com.express_scripts.field.nursing.common.files.excel.reader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTable;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.impl.CTTableImpl;

import com.express_scripts.field.nursing.common.files.excel.BaseXLS;

public abstract class BaseXLSReader extends BaseXLS {
	private final static Logger logger = Logger.getLogger(BaseXLSReader.class);
	
	public BaseXLSReader(Path sourceReportPath) {
		super(sourceReportPath);

	}

	protected CellStyle getDateFormat(String pattern) throws Exception {
		DataFormat df = this.wb.createDataFormat();
		CellStyle cs = this.wb.createCellStyle();  
		cs.setDataFormat(df.getFormat(pattern));
		
		return cs;

	}
	protected void openWorkbook(Path reportPath) throws Exception {
    	logger.info("Opening workbook: " + reportPath);
		this.sourceReportPath = reportPath;
		if (!reportPath.toFile().exists()){
			throw new FileNotFoundException(reportPath.toAbsolutePath() + " does not exist.");
		}
		
		try (FileInputStream fis = new FileInputStream(reportPath.toFile())){
			//this.wb = new HSSFWorkbook(fis);
			this.wb = WorkbookFactory.create(fis);
		}
	}
	
	protected Sheet getSheet(String sheetName) {
		Sheet sheet = this.wb.getSheet(sheetName);
		return sheet;
	}

	protected Sheet getSheetBeginingWith(char col, int row, String text) throws Exception {
		logger.debug(String.format("Searching for Sheet with '%s' at %c%d", text, col, row));

		int sheetsCount = this.wb.getNumberOfSheets();
		Sheet sheet = null;
		for (int i = 0; i < sheetsCount; i++) {
			sheet = getSheet(i);
			
			if (text.equals(getCellStringValue(sheet, col, row))){
				logger.trace(String.format("Sheet '%s' found at index %d", sheet.getSheetName(), i));
				break;
			}else{
				sheet = null;
			}
		}
		
		if (sheet == null){
			throw new Exception(String.format("Unable to find sheet with '%s' at %c%d", text, col, row));
		}
		
		return sheet;
	}

	
	protected boolean getCellBooleanValue(Sheet sheet, char col, int row) {
		logger.trace(String.format("Reading cell: %c%d", col, row));
		Cell cell = getCell(sheet, row, col);
		Boolean cellValue = cell.getBooleanCellValue();

		return cellValue;
	}
	protected double getCellNumericValue(Sheet sheet, char col, int row) {
		Cell cell = getCell(sheet, row, col);
		return cell.getNumericCellValue();
	}
	protected int getCellNumericIntValue(Sheet sheet, char col, int row) throws Exception{
		//logger.info(String.format("%s %c %d ", sheet.getSheetName(), col, row));
		Cell cell = getCell(sheet, row, col);
		String strValue;
		int intValue;
		if (Cell.CELL_TYPE_STRING == cell.getCellType()){
			strValue = cell.getStringCellValue();
			intValue = StringUtils.isBlank(strValue)?0:Integer.parseInt(strValue);
		}else if (Cell.CELL_TYPE_NUMERIC == cell.getCellType()){
			intValue = (int)cell.getNumericCellValue();
		}else if (Cell.CELL_TYPE_BLANK == cell.getCellType()){
			intValue = 0;
		}else{
			throw new Exception(String.format("Unable to parse numeric value in cell %s %c %d ", sheet.getSheetName(), col, row));
		}
		 
		return intValue;
	}
	protected float getCellNumericFloatValue(Sheet sheet, char col, int row) throws Exception{
		//logger.info(String.format("%s %c %d ", sheet.getSheetName(), col, row));
		Cell cell = getCell(sheet, row, col);
		String strValue;
		float value;
		if (Cell.CELL_TYPE_STRING == cell.getCellType()){
			strValue = cell.getStringCellValue();
			value = StringUtils.isBlank(strValue)?0:Integer.parseInt(strValue);
		}else if (Cell.CELL_TYPE_NUMERIC == cell.getCellType()){
			value = (float)cell.getNumericCellValue();
		}else if (Cell.CELL_TYPE_BLANK == cell.getCellType()){
			value = 0;
		}else{
			throw new Exception(String.format("Unable to parse numeric value in cell %s %c %d ", sheet.getSheetName(), col, row));
		}
		
		return value;
	}
	protected Date getCellDateValue(Sheet sheet, char col, int row){
		Cell cell = getCell(sheet, row, col);
		return cell.getDateCellValue();
	}

	protected Sheet getSheet(int sheetIndex) {
		Sheet sheet = this.wb.getSheetAt(sheetIndex);
		return sheet;
	}

	
	protected void saveReport()
			throws FileNotFoundException, IOException {
		try (FileOutputStream out = new FileOutputStream(this.sourceReportPath.toFile());){
			this.wb.write(out);
		}
	}

	/**
	 * Resolves 
	 *    a/b/c/myFile.txt
	 * to 
	 *    a/b/c/myFile_suffix.txt
	 *    
	 * @param source
	 * @param suffix
	 * @return
	 */
	protected Path resolveSibling(Path source, String suffix){
		StringBuffer newFileName = new StringBuffer(source.getFileName().toString());
		int extIndex = newFileName.lastIndexOf(".");
		newFileName.insert(extIndex, suffix);
		
		Path siblingPath = source.resolveSibling(newFileName.toString());

		return siblingPath;
	}
	
	protected int row(int rowIndex){
		return rowIndex - 1;
	}

	protected int col(char columnIndex){
		return Character.toUpperCase(columnIndex)-'A';
	}
	private XSSFTable getTable(Sheet sheet, String tableName){
		List<XSSFTable> tables =((XSSFSheet)sheet).getTables();
		XSSFTable table = null;
		for (XSSFTable xssfTable : tables) {
			if (xssfTable.getName().equals(tableName)){
				table = xssfTable;
				break;
			}
		}
		
		return table;
	}
	protected void resizeTable(Sheet sheet, String tableName, String startCell, String endCell){
		XSSFTable table = getTable(sheet, tableName);
		if (table!=null){
			CTTableImpl  ct = 	(CTTableImpl)table.getCTTable();
			ct.setRef(startCell+":"+endCell);
		}
	}
	
	protected String getTableStartCellReference(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String cell = String.format("%s%s"
				, table.getStartCellReference().getCellRefParts()[2]
				, table.getStartCellReference().getCellRefParts()[1]);
		return cell;
	}

	protected String getTableEndCellReference(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String cell = String.format("%s%s"
				, table.getEndCellReference().getCellRefParts()[2]
				, table.getEndCellReference().getCellRefParts()[1]);
		return cell;
	}

	protected String getTableLastColumn(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String column = table.getEndCellReference().getCellRefParts()[2];
		return column;
	}

	protected int getTableFirstDataRow(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		int row = Integer.parseInt(table.getStartCellReference().getCellRefParts()[1])+1;
		return row;
	}
	

	

	protected String getCellFormula(Sheet sheet, int rowInd, char colInd){
		Cell cell = getCell(sheet, rowInd, colInd);
		return cell.getCellFormula();
	}

}
