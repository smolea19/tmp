package com.express_scripts.field.nursing.common.files.excel;

import java.nio.file.Path;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public abstract class BaseXLS {
	private final static Logger logger = Logger.getLogger(BaseXLS.class);
	
	protected Workbook wb;
	protected Path sourceReportPath;
	protected OPCPackage pkg;
	
	public BaseXLS(Path sourceReportPath) {
		super();
		this.sourceReportPath = sourceReportPath;
	}
	
	protected String getCellStringValue(Sheet sheet, char col, int row) {
		logger.trace(String.format("Reading cell: %c%d", col, row));
		String cellValue=null;
		Cell cell = getCell(sheet, row, col);
		if (cell.getCellType() == 0 ){ //0: Numeric Avalue
			cellValue = ""+cell.getNumericCellValue();
		}else if(cell.getCellType() == 4){
			cellValue = Boolean.toString(cell.getBooleanCellValue());
		}else{
			cellValue = cell.getStringCellValue();
		}
		
		//logger.trace(String.format("Cell Value: %s", cellValue));
		return cellValue;
	}
	
	protected Cell getCell(Sheet sheet, int rowInd, char colInd){
		Row row = sheet.getRow(row(rowInd));
		if (row == null){
			row = sheet.createRow(row(rowInd));
		}
    	Cell cell = row.getCell(col(colInd));
    	if (cell == null){
    		cell = row.createCell(col(colInd));
    	}
    	return cell;
	}
	
	protected int row(int rowIndex){
		return rowIndex - 1;
	}

	protected int col(char columnIndex){
		return columnIndex-'A';
	}



}
