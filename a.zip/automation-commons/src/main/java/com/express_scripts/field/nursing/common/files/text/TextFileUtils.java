package com.express_scripts.field.nursing.common.files.text;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;

public final class TextFileUtils {

	//private static final Logger LOG = LogManager.getLogger(TextFileUtils.class);

	private TextFileUtils() {
		// No call 
	}

    public static void stringToFile(Path dstFile, List<String> contents) throws IOException {
    	Files.write(dstFile,contents,Charset.defaultCharset());
    }
    public static void stringToFile(Path dstFile, String contents) throws IOException {
    	Files.write(dstFile, contents.getBytes());
    }
    public static String fileToString(Path srcFile) throws IOException {
    	return new String(Files.readAllBytes(srcFile));
    }

//	public static List<String> fileToListOfStrings(Path path) throws IOException {
//        List<String> list = new ArrayList<>();
//
//        try (Stream<String> stream = Files.lines(path)) {
//            list = stream
//                    .collect(Collectors.toList());
//
//        } 
//
//        return list;
//	}
}
