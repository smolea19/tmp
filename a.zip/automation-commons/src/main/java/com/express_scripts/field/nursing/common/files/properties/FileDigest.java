package com.express_scripts.field.nursing.common.files.properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public final class FileDigest {

	private static final Logger LOG = LogManager.getLogger(FileDigest.class);

	private FileDigest() {
		// No call
	}
	private static String getFileChecksum(MessageDigest digest, Path filePath) throws IOException
	{
	    readFileIntoMessageDiggest(digest, filePath);

	    byte[] bytes = digest.digest();
	    
	    String checksum = DigestUtils.convertBytesArrayToHexFormat(bytes);
	     
	   return checksum;
	}
	private static void readFileIntoMessageDiggest(MessageDigest digest, Path filePath)
			throws IOException, FileNotFoundException {
		//Get file input stream for reading the file content
		try (FileInputStream fis = new FileInputStream(filePath.toFile())){
			//Create byte array to read data in chunks
			byte[] byteArray = new byte[1024];
			int bytesCount = 0; 
			
			//Read file data and update in message digest
			while ((bytesCount = fis.read(byteArray)) != -1) {
				digest.update(byteArray, 0, bytesCount);
			}
		}
	}
	
	public static boolean compareMD5Checksum(String file1, String file2) throws Exception {
		return compareMD5Checksum(Paths.get(file1), Paths.get(file2));
	}
	public static boolean compareMD5Checksum(Path filePath1, Path filePath2) throws Exception {
		String checksum1 = getMD5Checksum(filePath1);
		String checksum2 = getMD5Checksum(filePath2);
		
		return checksum1.equals(checksum2);
	}
	public static String getMD5Checksum(String file) throws Exception {
		return getMD5Checksum(Paths.get(file));
	}
	

	public static String getMD5Checksum(Path filePath) throws Exception {
		//Use MD5 algorithm
		MessageDigest md5Digest = MessageDigest.getInstance("MD5");

		//Get the checksum
		String checksum = getFileChecksum(md5Digest, filePath);
		 
		//see checksum
		LOG.debug(checksum);
		
		return checksum;
				
	}
	
	public static String getSHA1Checksum(String file) throws Exception {
		return getSHA1Checksum(Paths.get(file));
	}
	public static String getSHA1Checksum(Path filePath) throws Exception {
		//Use MD5 algorithm
		MessageDigest md5Digest = MessageDigest.getInstance("SHA-1");
		
		//Get the checksum
		String checksum = getFileChecksum(md5Digest, filePath);
		
		//see checksum
		LOG.info(checksum);
		
		return checksum;

	}
}
