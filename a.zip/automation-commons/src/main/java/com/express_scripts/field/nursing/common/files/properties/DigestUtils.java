package com.express_scripts.field.nursing.common.files.properties;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public final class DigestUtils {

	private static final Logger LOG = LogManager.getLogger(DigestUtils.class);
	
	private DigestUtils() {
		// not called
	}

	public static String md5(String message) {
		//Use MD5 algorithm
		MessageDigest md5Digest = createMessageDigest("MD5");

		byte[] diggestedMessageBytes = diggestMessage(message, md5Digest);
	     
	    String md5String = convertBytesArrayToHexFormat(diggestedMessageBytes);
	    //LOG.trace(md5);

	   return md5String;
	   
	}

	private static byte[] diggestMessage(String message, MessageDigest md5Digest) {
		//Get the checksum
		md5Digest.update(message.getBytes());
		
		//Get the hash's bytes
	    return md5Digest.digest();
	}

	public static String convertBytesArrayToHexFormat(byte[] bytes) {
		//This bytes[] has bytes in decimal format;
	    StringBuilder md5Sb = new StringBuilder();
	    for(int i=0; i< bytes.length ;i++)
	    {
	        md5Sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
	    }
	    return  md5Sb.toString();
	}

	private static MessageDigest createMessageDigest(String algorithm) {
		MessageDigest md5Digest = null;
		try {
			md5Digest = MessageDigest.getInstance(algorithm);
		} catch (NoSuchAlgorithmException e) {
			LOG.error(e, e);
		}
		return md5Digest;
	}
	

}
