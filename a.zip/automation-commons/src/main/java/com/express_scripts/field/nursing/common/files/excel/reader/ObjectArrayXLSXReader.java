package com.express_scripts.field.nursing.common.files.excel.reader;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;

public class ObjectArrayXLSXReader extends BaseXLSReader {
	private final static Logger logger = Logger.getLogger(ObjectArrayXLSXReader.class);
	
	public ObjectArrayXLSXReader(Path sourceReportPath) {
		super(sourceReportPath);
	}
	
	public static void main(String[] args) throws Exception{
		//Define datasource folders 
		Path rootFolder = Paths.get("E:\\OleaSVN\\tools\\bats\\config");
		Path dataFolder = rootFolder.resolve(".");
		Path dataReport = dataFolder.resolve("HeyConfig.xlsx");
		
		String sheetName = "Actions";

		//Creates Formatter instance
		ObjectArrayXLSXReader xlsReader = new ObjectArrayXLSXReader(dataReport);

		List<Object[]> objectsList = xlsReader.readReport(sheetName);
		
		for (Object[] objectArray : objectsList) {
			for (Object object : objectArray) {
				System.out.print(object + "\t");
			}
			System.out.println();
		}
		
		
		
		//logger.info("ITAllocationDTOList: " + dto);
		//Saves existing bookmarks into Excel
		//Path reportPath = Paths.get(".\\etc\\bookmarks").resolve(TimeUtils.getTimestamp()+".xlsx");
		//Path masterReportPath = Paths.get(".\\etc\\bookmarks\\config\\Bookmarks.xlsx");
		//BookmarksXLSXWriter bookmarksXLSXWriter = new BookmarksXLSXWriter(bookmarksList, reportPath, masterReportPath);
		//bookmarksXLSXWriter.createReport();
		logger.info("End");
	}

	public List<Object[]> readReport(String sheetName) throws Exception {
    	logger.info("Reading " + this.sourceReportPath);
    	
    	//Open Workbook
    	openWorkbook(this.sourceReportPath);

		//Switch Data Sheet 
		Sheet sheet = getDataSheet(sheetName);
		
		//Load data
		List<Object[]> list = loadData(sheet);
		
        logger.debug("Data has been read successfully.");
        return list;
	}

	private List<Object[]> loadData(Sheet sheet) throws Exception{
		//logger.info("Reading data from: " + sheet.getSheetName());
		Object[] objArray;
		List<Object[]> list = new ArrayList<>();
		String name, baseurl, url, iconFile;
		List<String> categories;
		String content;
		
		char col = 'A';
		char lastCol = col;
		int headersRow = 1;
		
		String header;
		do{
			header = getCellStringValue(sheet, lastCol, headersRow);
			//System.out.println(((char)lastCol) +": "+ header);
			lastCol++;
		}while(!StringUtils.isBlank(header));
		
		List rowObject;
		
		for (int row = sheet.getFirstRowNum()+headersRow+1; row <= sheet.getLastRowNum()+1; row++) {
			col = 'A';
			
			rowObject = new ArrayList<>();
			
			for (; col < lastCol; col++){
				rowObject.add(getCellStringValue(sheet, col, row));
			}

			list.add(rowObject.toArray());
		}
		
		return list;
	}

	private List<String> getCategories(Sheet sheet, char col, int row) {
		List<String> categories = new ArrayList<>();
		
		while (StringUtils.isNotEmpty(getCellStringValue(sheet, col, row))) {
			categories.add(getCellStringValue(sheet, col++, row));
		}
		
		return categories;
	}

	private Sheet getDataSheet(String sheetName) throws Exception {
		Sheet sheet = getSheet(sheetName);
		return sheet;
		
	}	

}
