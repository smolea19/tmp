package com.express_scripts.field.nursing.common.sqlserver;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.express_scripts.field.nursing.common.files.text.TextFileUtils;

public class SQLServerClient {
	
	private static String userName;
	private static String password;
	private static String url;
	
	static {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	
	public SQLServerClient() {
		userName = "APAdmin";
		password = "sqlComplex@123";
		//url = "jdbc:sqlserver://CH3DW018037:1433"+ ";databaseName=AccessPointSYSI";
		url = "jdbc:sqlserver://CH3DW018037:1433"+ ";databaseName=AccessPointQA";

	}
	
	public static void main(String[] args) throws Exception {
		SQLServerClient sqlServerClient = new SQLServerClient();

		Path sqlFile = Paths.get("etc\\sql\\accessPoint\\sample2.sql");
		//sqlServerClient.runSQLQuery(sqlFile);

		Path updateSqlFile = Paths.get("..\\ACN\\etc\\sql\\accessPoint\\wipeoutTodaysAppointments2.sql");
		sqlServerClient.executeSQL(updateSqlFile);
		
		//qlServerClient.runSQLQuery(sqlFile);
		
	}
		
	public List<String[]> runSQLQuery(Path sqlFile) throws Exception {
		return runSQLQuery(TextFileUtils.fileToString(sqlFile));
	}
	public void executeSQL(Path sqlFile) throws Exception {
		executeSQL(TextFileUtils.fileToString(sqlFile));
	}
	public List<String[]> runSQLQuery(String sqlQuery) throws Exception {
		
		List<String[]> columnNamesAndResultsList = new ArrayList<>();
		
		try(Connection con = DriverManager.getConnection(url, userName, password);
		    Statement s1 = con.createStatement()){

			ResultSet rs = s1.executeQuery(sqlQuery);
			if (rs != null) {
				
				String[] columnNames = extractColumnNames(rs);
				
				columnNamesAndResultsList.add(columnNames);
				
				List<String[]> resultsList = extractResults(rs);
				
				columnNamesAndResultsList.addAll(resultsList);
				
			}


		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return columnNamesAndResultsList;
	}

	public void executeSQL(String statement) throws Exception {
		
		try(Connection con = DriverManager.getConnection(url, userName, password);
				Statement s1 = con.createStatement()){
			
			boolean executionFlag = s1.execute(statement);
			
			System.out.println("executionFlag: " + executionFlag);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private List<String[]> extractResults(ResultSet rs) throws SQLException {
		List<String[]> resultsList = new ArrayList<>();
		int columns = rs.getMetaData().getColumnCount();
		String[] result;
		while (rs.next()) {
			result = new String[columns];
			for (int j = 0; j < result.length; j++) {
				result[j] = rs.getString(j+1);
				System.out.print(result[j] + "\t");
			}
			resultsList.add(result);
			System.out.println("");
		}
		
		return resultsList;

	}
	private String[] extractColumnNames(ResultSet rs) throws SQLException {
		int columns = rs.getMetaData().getColumnCount();
		String[] result = new String[columns];
		for (int j = 0; j < result.length; j++) {
			result[j] = rs.getMetaData().getColumnLabel(j+1);
			System.out.print(result[j] + "\t");
		}
		System.out.println("");
		return result;
	}

}