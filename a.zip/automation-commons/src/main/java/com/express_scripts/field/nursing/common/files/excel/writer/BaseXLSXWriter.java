package com.express_scripts.field.nursing.common.files.excel.writer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTable;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.impl.CTTableImpl;

import com.express_scripts.field.nursing.common.files.excel.BaseXLS;

public abstract class BaseXLSXWriter extends BaseXLS {
	private final static Logger logger = Logger.getLogger(BaseXLSXWriter.class);
	
	private final Path masterReportPath;
	private CreationHelper creationHelper;
	private Font boldFont;
	private Font redFont;
	
	
	
	public BaseXLSXWriter(Path reportPath, Path masterReportPath) {
		super(reportPath);
		this.masterReportPath = masterReportPath;
	}

	protected CellStyle getDateFormat(String pattern) throws Exception {
		DataFormat df = this.wb.createDataFormat();
		CellStyle cs = this.wb.createCellStyle();  
		cs.setDataFormat(df.getFormat(pattern));
		
		return cs;

	}
	protected void openWorkbook(Path reportPath) throws Exception {
		this.sourceReportPath = reportPath;
		if (!reportPath.toFile().exists()){
			createReport(reportPath);
		}
		
		try (FileInputStream fis = new FileInputStream(reportPath.toFile())){
			this.pkg = OPCPackage.open(fis);
			this.wb = new XSSFWorkbook(this.pkg);
			
			 this.creationHelper = wb.getCreationHelper();
			 
			 boldFont = wb.createFont();
			 boldFont.setBold(true);

			 redFont = wb.createFont();
			 redFont.setColor(IndexedColors.RED.getIndex());
			 redFont.setBold(true);
		}finally{
			this.pkg.close();
		}
	}
	
	protected Sheet getSheet(String sheetName) {
		Sheet sheet = this.wb.getSheet(sheetName);
		unhideSheet(sheetName);
		return sheet;
	}

	protected void unhideSheet(String sheetName) {
		this.wb.setSheetHidden(this.wb.getSheetIndex(sheetName), 0);
	}

	
	private Path createReport(Path dest) throws Exception {
		
		Path source = this.masterReportPath;

		Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
		
		return dest;
	}

	
	protected void saveReport()
			throws FileNotFoundException, IOException {
		try (FileOutputStream out = new FileOutputStream(this.sourceReportPath.toFile());){
			this.wb.write(out);
		}finally{
			this.wb.close();
			this.pkg.close();
		}
	}

	/**
	 * Resolves 
	 *    a/b/c/myFile.txt
	 * to 
	 *    a/b/c/myFile_suffix.txt
	 *    
	 * @param source
	 * @param suffix
	 * @return
	 */
	protected Path resolveSibling(Path source, String suffix){
		StringBuffer newFileName = new StringBuffer(source.getFileName().toString());
		int extIndex = newFileName.lastIndexOf(".");
		newFileName.insert(extIndex, suffix);
		
		Path siblingPath = source.resolveSibling(newFileName.toString());

		return siblingPath;
	}
	
	protected int row(int rowIndex){
		return rowIndex - 1;
	}

	protected int col(char columnIndex){
		return Character.toUpperCase(columnIndex)-'A';
	}
	private XSSFTable getTable(Sheet sheet, String tableName){
		List<XSSFTable> tables =((XSSFSheet)sheet).getTables();
		XSSFTable table = null;
		for (XSSFTable xssfTable : tables) {
			if (xssfTable.getName().equals(tableName)){
				table = xssfTable;
				break;
			}
		}
		
		return table;
	}
	protected void resizeTable(Sheet sheet, String tableName, String startCell, String endCell){
		XSSFTable table = getTable(sheet, tableName);
		if (table!=null){
			CTTableImpl  ct = 	(CTTableImpl)table.getCTTable();
			ct.setRef(startCell+":"+endCell);
		}
	}
	
	protected String getTableStartCellReference(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String cell = String.format("%s%s"
				, table.getStartCellReference().getCellRefParts()[2]
				, table.getStartCellReference().getCellRefParts()[1]);
		return cell;
	}

	protected String getTableEndCellReference(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String cell = String.format("%s%s"
				, table.getEndCellReference().getCellRefParts()[2]
				, table.getEndCellReference().getCellRefParts()[1]);
		return cell;
	}

	protected String getTableLastColumn(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		String column = table.getEndCellReference().getCellRefParts()[2];
		return column;
	}

	protected int getTableFirstDataRow(Sheet sheet, String tableName){
		XSSFTable table = getTable(sheet, tableName);
		int row = Integer.parseInt(table.getStartCellReference().getCellRefParts()[1])+1;
		return row;
	}
	

	protected Cell getCell(Sheet sheet, int rowInd, char colInd){
		Row row = sheet.getRow(row(rowInd));
		if (row == null){
			row = sheet.createRow(row(rowInd));
		}
    	Cell cell = row.getCell(col(colInd));
    	if (cell == null){
    		cell = row.createCell(col(colInd));
    	}
    	return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, String value){
		Cell cell = getCell(sheet, rowInd, colInd);
		//cell.setCellValue(paramRichTextString)
		cell.setCellValue(value==null?"":value.trim());
		return cell;
	}
	protected Cell setCellNoTrim(Sheet sheet, int rowInd, char colInd, String value){
		Cell cell = getCell(sheet, rowInd, colInd);
		//cell.setCellValue(paramRichTextString)
		cell.setCellValue(value==null?"":value.trim());
		return cell;
	}

	protected Cell setCellWithBolds(Sheet sheet, int rowInd, char colInd, String value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(formatValue(value));
		return cell;
	}
	
	private RichTextString formatValue (String value){
		if (value == null){
			return new XSSFRichTextString("");
		}
		RichTextString richTextString = new XSSFRichTextString(value.trim());
		applyFont(boldFont, richTextString, "Calculation:");
		applyFont(boldFont, richTextString, "Current Values:");
		applyFont(boldFont, richTextString, "eForm field:");
		applyFont(boldFont, richTextString, "eForm fields:");
		applyFont(boldFont, richTextString, "Required Rule indicated by:");
		applyFont(boldFont, richTextString, "Field      :");
		applyFont(boldFont, richTextString, "Expected   :");
		applyFont(boldFont, richTextString, "Actual     :");
		applyFont(boldFont, richTextString, "eForm cell :");
		applyFont(boldFont, richTextString, "JSON  :");
		applyFont(boldFont, richTextString, "eForm :");
		applyFont(boldFont, richTextString, "JSON:");
		
		applyFont(redFont, richTextString, "NOT FOUND");
		
		return richTextString;
	}
	
	private void applyFont(Font font, RichTextString richTextString, String value) {
		int startIndex = richTextString.getString().indexOf(value); 
		int endIndex = startIndex + value.length();
		
		if (startIndex>=0){
			richTextString.applyFont(startIndex, endIndex, font);
		}
	}

	
	protected Cell setCellFormula(Sheet sheet, int rowInd, char colInd, String formula){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellFormula(formula);
		return cell;
	}
	protected String getCellFormula(Sheet sheet, int rowInd, char colInd){
		Cell cell = getCell(sheet, rowInd, colInd);
		return cell.getCellFormula();
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, Date value, CellStyle cellStyle){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		cell.setCellStyle(cellStyle);
		return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, int value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, Long value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		return cell;
	}

	protected Cell setCellComment(Sheet sheet, int rowInd, char colInd, String commentValue){
		Cell cell = getCell(sheet, rowInd, colInd);
		
		Drawing drawing = sheet.createDrawingPatriarch();
		ClientAnchor anchor = creationHelper.createClientAnchor();
		Comment comment = drawing.createCellComment(anchor);
	    RichTextString str = creationHelper.createRichTextString(commentValue);
	    comment.setString(str);
	    comment.setAuthor("Sergio Olea");
	    
		cell.setCellComment(comment);
		return cell;
	}

	protected Cell setCell(Sheet sheet, int rowInd, char colInd, boolean value){
		Cell cell = getCell(sheet, rowInd, colInd);
		cell.setCellValue(value);
		return cell;
	}

}
