package com.express_scripts.field.nursing.common.http;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;


public class HTTPClient {
	private final static Logger LOG = Logger.getLogger(HTTPClient.class);

	public String makePostRequest(String endUrl, String payload) throws Exception{
		MyHttpClient httpClient = new MyHttpClient();
		
		List<NameValuePair> headers = new ArrayList();
		headers.add(new BasicNameValuePair("Content-Type", "application/xml; charset=utf-8"));
		
		LOG.debug("Payload:" + payload);
		
		HttpResponse httpResponse = httpClient.sendPost(endUrl, headers, payload);
		
		LOG.debug(httpResponse);
		String response  = MyHttpClient.extractResponse(httpResponse);
		return response;
	}
}
