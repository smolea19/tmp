package com.express_scripts.field.nursing.common.files.properties;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.common.files.tree.FindFiles;

public final class FilesLastUpdateCalculator {
	private static final Logger LOG = LogManager.getLogger(FilesLastUpdateCalculator.class);
	
	private FilesLastUpdateCalculator() {
		// No call 
	}
	/**
	 * Handles files, jar entries, and deployed jar entries in a zip file (EAR).
	 * @return The date if it can be determined, or null if not.
	 */
	public static String getClassBuildTime(Class<?> currentClass) {
	    Date date = null;

	    Path basePath = Paths.get("."); 
	    
	    //Class<?> currentClass = new Object() {}.getClass().getEnclosingClass();
	    URL resource = currentClass.getResource(currentClass.getSimpleName() + ".class");

	    if (resource != null) {
	        if (resource.getProtocol().equals("file")) {
	            date = getDateForLastFileModifiedInFolder(basePath, "*.{class}");
	        } else if (resource.getProtocol().equals("jar")) {
	            date = getJarModifiedDate(resource);
	        } else if (resource.getProtocol().equals("zip")) {
	            date = getZipLasModifiedDate(resource);
	        }
	    }
	    
	    SimpleDateFormat sdf = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss zzz");

	    String buildTime = "Built on: " + sdf.format(date); 
	    
	    LOG.trace(buildTime);
	    
	    return buildTime;
	}
	private static Date getZipLasModifiedDate(URL resource) {
		String tmpPath = resource.getPath();
		File jarFileOnDisk = new File(tmpPath.substring(0, tmpPath.indexOf('!')));
		Date date = null;
		try(JarFile jarFile = new JarFile (jarFileOnDisk)) {
		    ZipEntry zipEntry = jarFile.getEntry (tmpPath.substring(tmpPath.indexOf('!') + 2));//Skip the ! and the /
		    long zeTimeLong = zipEntry.getTime ();
		    Date zeTimeDate = new Date(zeTimeLong);
		    date = zeTimeDate;
		} catch (IOException|RuntimeException ignored) { }
		return date;
	}
	private static Date getJarModifiedDate(URL resource) {
		Date date;
		Path path;
		String tmpPath = resource.getPath();
		LOG.trace(tmpPath);
		tmpPath = tmpPath.substring(0, tmpPath.indexOf('!'));
		LOG.trace(tmpPath);
		path = Paths.get(URI.create(tmpPath));
		date = getFileLastModified(path);
		return date;
	}

	
	private static Date getFileLastModified(Path file) {
		Date date = new Date(file.toFile().lastModified());
		LOG.trace(date + " " + file);
		return date;
	}
	
	private static Date getDateForLastFileModifiedInFolder(Path startingDirPath, String mask) {
		List<Path> filesInFolder = new ArrayList<>();
		try {
			filesInFolder = FindFiles.find(startingDirPath, mask);
		} catch (IOException e) {
			LOG.fatal(e, e);
		}
		Date lastModified = getMaxModifiedDate(filesInFolder);
		LOG.trace(lastModified);
		return lastModified;
	}

	private static Date getMaxModifiedDate(List<Path> filesInFolder) {
		Date maxModifiedDate = null;
		Date tmpModifiedDate;
		boolean newMaxModifiedDate;
		for (Path file : filesInFolder) {
			tmpModifiedDate = getFileLastModified(file);
			
			newMaxModifiedDate = maxModifiedDate == null
					          || tmpModifiedDate.after(maxModifiedDate);
			
			if (newMaxModifiedDate){
				maxModifiedDate = tmpModifiedDate;
			}
		}
		return maxModifiedDate;
	}
}
