package com.express_scripts.field.nursing.access.point.properties;

import java.util.Date;
import java.util.ResourceBundle;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.common.AbstractProperties;




public final class AutomationProperties extends AbstractProperties {
	private static final Logger LOG = LogManager.getLogger(AutomationProperties.class);
	private static final String VERSION =  "[Morning report] 5/28 8:27 - " + getClassBuildTime(AutomationProperties.class);
	private static final ClassLoader cl = Thread.currentThread().getContextClassLoader();
	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("automation");
	
	static {
		LOG.info(getVersion());
	}
	
	
	private AutomationProperties() {
		super();
		//No Call
	}
	public static String getVersion() {
		return getVersion(VERSION, RESOURCE_BUNDLE) + " "+ cl.getResource("automation.properties");
	}

	public static String getProperty(String key) {
		return getProperty(key, RESOURCE_BUNDLE);
	}
	public static char[] getCharArrayProperty(String key) {
		return getCharArrayProperty(key, RESOURCE_BUNDLE);
	}

	public static long getLongProperty(String key) {
		return getLongProperty(key, RESOURCE_BUNDLE);
	}

	public static Date getTimeHHmmProperty(String key) {
		String timeStr = getProperty(key, RESOURCE_BUNDLE);
	
		String[] triggerHourStrSplit = timeStr.split(":");
	    int triggerHour = Integer.parseInt(triggerHourStrSplit[0]);
	    int triggerMin = Integer.parseInt(triggerHourStrSplit[1]);

		Date date = new Date();
		date = DateUtils.setHours(date, triggerHour);
		date = DateUtils.setMinutes(date, triggerMin);
		date = DateUtils.setSeconds(date, 0);
		
		return date;
	}
	
	public static void main(String[] args) {
		AutomationProperties.getProperty("hello.world");
	}
	
}
