package com.express_scripts.field.nursing.automation.access.point.screens;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

public class OpenAppointmentsDetailsScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(OpenAppointmentsDetailsScreen.class);
	
	public OpenAppointmentsDetailsScreen() {
		LOG.info("Default constructor");
	}

}
