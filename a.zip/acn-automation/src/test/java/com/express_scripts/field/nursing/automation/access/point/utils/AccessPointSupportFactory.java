package com.express_scripts.field.nursing.automation.access.point.utils;


public class AccessPointSupportFactory {
	private static AccessPointSupport accessPointSupport;
	
	private AccessPointSupportFactory() {
		//Empty constructor
	}
	
	public static AccessPointSupport getInstance(){
		if (accessPointSupport == null){
			accessPointSupport = new AccessPointSupport();
		}
		
		return accessPointSupport;
	}
}
