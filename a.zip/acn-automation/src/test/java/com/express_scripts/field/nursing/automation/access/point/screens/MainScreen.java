package com.express_scripts.field.nursing.automation.access.point.screens;

import java.text.SimpleDateFormat;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class MainScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(MainScreen.class);

	public MainScreen() {
		LOG.info("Default login.");
	}
//
	
	@Then("^click on conflicting appointment green icon$")
	public void clickOnGreenIcon() throws Throwable {
		String appointmentDate =  new SimpleDateFormat("h:mm a").format(AccessPointInputData.Appointment.conflictDate);
		String xPath = String.format("//*[contains(text(),'%s')]/ancestor::tr//input[@type='image']", appointmentDate);
	    clickByXPath(xPath);
	}
}
