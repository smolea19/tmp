package com.express_scripts.field.nursing.automation.access.point.screens;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class AddNewPatientScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(AddNewPatientScreen.class);
	
	@Then("^enter Patient Id")
	public void enterPatientId() throws Throwable {
		LOG.info("Entering patient id");
		
		switchToFrame("PopupFrame0");
		
		String ptId = AccessPointInputData.Patient.id;
		
		enterTextIntoTextboxByPartialId("tbxPatientId", ptId);
		
	}
	
	@Then("^click on found Patient Id link \\(Add New Patient Screen\\)$$")
	public void clickOnPatientLink() throws Throwable {
		String ptId = AccessPointInputData.Patient.id;
		
		clickLink(ptId);
		
		//waitSeconds(10);
		waitForTextToAppear("tbxLastName");
		waitForTextToAppear("tbxFirstName");
		
		AccessPointInputData.Patient.lastName = readTextboxByPartialId("tbxLastName");
		AccessPointInputData.Patient.firstName = readTextboxByPartialId("tbxFirstName");
		AccessPointInputData.Patient.abbrev = AccessPointInputData.Patient.firstName.substring(0,1)
											+ AccessPointInputData.Patient.lastName.substring(0,1); 
		
	}
	

}
