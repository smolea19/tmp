package com.express_scripts.field.nursing.automation.access.point.screens;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	plugin= {"pretty", "html:target/report"} 
	, tags = {"@Scenario1"}
	, snippets = SnippetType.CAMELCASE
	)
//@CucumberOptions(features = "Feature/TicketRestartServers.feature", tags = {"~@Scenario2","~@Scenario3","~@Scenario4"},  plugin = "json:target/cucumber-report-json") 
public class RunCukesTest {
	static {
		//-Dwebdriver.firefox.bin="C:\esi\apps\FireFox\Mozilla Firefox\firefox.exe"
		System.setProperty("webdriver.firefox.bin", "C:\\esi\\apps\\FireFox\\Mozilla Firefox\\firefox.exe");
	}
	

}
