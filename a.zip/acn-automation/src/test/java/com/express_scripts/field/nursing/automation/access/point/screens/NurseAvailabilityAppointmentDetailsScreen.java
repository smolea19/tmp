package com.express_scripts.field.nursing.automation.access.point.screens;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class NurseAvailabilityAppointmentDetailsScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(NurseAvailabilityAppointmentDetailsScreen.class);
	

	@Then("^confirm patient appointment$")
	public void confirmPatientAppointment() throws Throwable {
		LOG.info("Confirmint patient appointment.");
		
		switchToFrame("PopupFrame0");
			
		checkCheckboxByPartialId("cbxPatientConfirmed");
		
		clickButton("Confirm Patient Appt.");
	}

	@Then("^confirm nurse appointment$")
	public void confirmNurseAppointment() throws Throwable {
		switchToFrame("PopupFrame0");
		
		checkCheckboxByPartialId("cbxNurseConfirmed");
		
		clickButton("Confirm Nurse");
	}

}
