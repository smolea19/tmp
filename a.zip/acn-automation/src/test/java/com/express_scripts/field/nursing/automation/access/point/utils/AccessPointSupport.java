package com.express_scripts.field.nursing.automation.access.point.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AccessPointSupport extends BaseTesting {
	//$ mvn clean test -Dcucumber.options="--tags @Scenario1" 
	
	public AccessPointSupport() {
		super();
	}
	
	public String pm ="PM";
	public String time3;
	public int tdId;
	public String dateApptLoc;
	public String timeApptLoc;
	public String dateApptTime;
	public String timeApptTime;
	public String dateApptThe;
	public String timeApptThe;
	public int positionList=0;
	public int positionRecord=0;
	


	/* TH in Open Appointments screen*/
	public boolean thExist(WebElement row){
		try {
			row.findElement(By.tagName("th")).getText();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	public boolean divExist(WebElement row){
		try {
			row.findElement(By.tagName("div")).getText();
			System.out.println("THIS IS THE DIVEXIST VALUE --- " + row.findElement(By.tagName("div")).getText());
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	public int getHourTh(WebElement calendar, String time3){
		WebElement thead=calendar.findElement(By.tagName("thead"));
		System.out.println("Calendar***"  + thead.getText());
		List<WebElement> hours=thead.findElements(By.tagName("th"));
		for(int i=0;i<hours.size();i++){
		System.out.println("GETHOURMETHOD" + hours.get(i).getText().trim() + "THIS IS TIME3" + time3);
			if(hours.get(i).getText().trim().equalsIgnoreCase(time3.trim())){
				System.out.println("GETHOURMETHOD IS IN THE IFFFFFFFFFF and the value return by i :" + i); 
				return i;
			}
		}
		return 0;
	}
	
	

	
	public void appointmentDetails() throws Throwable {
		
		WebElement fr = driver.findElement(By.id("PopupFrame0"));
		driver.switchTo().frame(fr);
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_trButtonsOpen")));
	
		WebElement btnOverride = driver.findElement(By.xpath("//*[@onclick='"+"ShowOverride ();"+"']"));
		btnOverride.click();
		
		driver.switchTo().defaultContent();
		overrideFunction();
		
		driver.switchTo().defaultContent();
		WebElement linkNurseAvailability = driver.findElement(By.linkText("Nurse Availability"));
		linkNurseAvailability.click();
		nurse_availability_screen();
	}
	
	
	public void overrideFunction() throws Throwable {
		
		WebElement divOverride = driver.findElement(By.id("sectionWrapperDiv1"));
		WebElement fr = divOverride.findElement(By.id("PopupFrame1"));
		driver.switchTo().frame(fr);
		
		WebElement nurseId = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_tbxNurseId"));
		nurseId.sendKeys("75244");
		
		WebElement btnSearch = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnSearch"));
	    btnSearch.click();
	    
	    WebElement linkNurseId = driver.findElement(By.linkText("75244"));
	    linkNurseId.click();
	    
	    WebElement bttnOverrideNurse  = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnOverride"));
	    bttnOverrideNurse.click();
	    
	    switchFrame();
	    WebElement bttnAssign  = driver.findElement(By.id("btnAssign"));
	    bttnAssign.click();
	}
	
public void switchFrame() throws Throwable {
	    
	driver.switchTo().defaultContent();
	WebElement fr = driver.findElement(By.id("PopupFrame0"));
	driver.switchTo().frame(fr);
		
	}
	

public void switchToFrame1() throws Throwable {
    
	driver.switchTo().defaultContent();
    WebElement fr = driver.findElement(By.id("PopupFrame1"));
	driver.switchTo().frame(fr);
	
}

/* THEAD in Open Appointments screen*/
public boolean theadExist(WebElement row){
	try {
		System.out.println("///THIS THEAD AVAILABILITY///" + row.findElement(By.tagName("thead")).getText() );
		row.findElement(By.tagName("thead")).getText();
		return true;
	} catch (Exception e) {
		return false;
	}
}

public void nurse_availability_screen() throws Throwable {
    
	WebElement div = driver.findElement(By.id("content"));
	WebElement calendarTable = div.findElement(By.className("Calendar"));
	
	List<WebElement> row = calendarTable.findElements(By.tagName("tr"));
	for (WebElement value : row) {  
		String rowValueAvailability = value.getText();
		System.out.println("///THIS IS THE VALUE FOR ROW IN AVAILABILITY///" + rowValueAvailability);
		if(thExist(value)){
		System.out.println("THIS IS THE THEAD VALUE  FOR AVAILABILITY"+value.findElement(By.tagName("th")).getText());
		}//end if th exist
		else{
			if(rowValueAvailability.contains("PINTO, JOSUE")){
				System.out.println("THIS IS THE EXPECTED ROW FOR AVAILABILITY***");
				List<WebElement> tds=value.findElements(By.tagName("td"));
				int rowReturn = getHourTh(calendarTable, time3);
				System.out.println("THIS IS THE ROWRETURN VALUE *---* "+ rowReturn);
				if(divExist(value)){
					 WebElement td= tds.get(rowReturn + 2);
					 tdId= rowReturn + 2;
						WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")); 
						//WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td[7]/table/tbody/tr/td/div/span[2]/span")); 
						System.out.println("THIS IS THE VALUE FOR TDID in the first confirmation --- " + tdId);
						bttnApptAvailability.click();
				     appDetail_ConfirmAppointment();
					 
				 }else {
					 System.out.println("THERE IS NOT DIV AND I DONT KNOW WHYYYY --- ");
				 }
			}
		}
      }
  }


public void appDetail_ConfirmAppointment() throws Throwable {
    
	driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	switchFrame();
	WebElement chkConfirmPatient = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_lvPatient_ctrl0_cbxPatientConfirmed"));
	chkConfirmPatient.click();
	WebElement bttnConfirmPatient = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnConfirmPatient"));
	bttnConfirmPatient.click();
	WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")); 
	//WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td[7]/table/tbody/tr/td/div/span[2]/span")); 
	System.out.println("THIS IS THE VALUE FOR TDID --- " + tdId);
	bttnApptAvailability.click();
	switchFrame();
	WebElement chkConfirmNurse = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_lvNurse_ctrl0_cbxNurseConfirmed"));
	chkConfirmNurse.click();
	WebElement bttnConfirmNurse = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnConfirmNurse"));
	bttnConfirmNurse.click();
	
}

	

	public void afterSix() throws Throwable{
		
		System.out.println("THIS IS THE EXPECTED for after six non patient ***");
		WebDriverWait wait = new WebDriverWait(driver,20);
 	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ctl00_WorkShiftSelect") ));
		WebElement selectShift = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ctl00_WorkShiftSelect"));
		Select dropdownReason = new Select(selectShift);
		dropdownReason.selectByVisibleText("6pm - 6am");
		
		
		
	}

	public String reportDateFormat() throws Throwable {
		
		DateFormat dateFormat = new SimpleDateFormat ("yyyy/MM/dd hh:mm:ss a");
		Date today = Calendar.getInstance().getTime();
		String reportDate = dateFormat.format(today);
		System.out.println("Todays Date is " + reportDate);
		
		return reportDate;
	}
	
	public String timeHHMM() throws Throwable {
		
		String dateTime = reportDateFormat();
		Date date = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss a").parse(dateTime);
		String time = new SimpleDateFormat("hh:mm").format(date);
   		return time;

		
	}
	
public String timeMM() throws Throwable {
		
		String dateTime = reportDateFormat();
		Date date = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss a").parse(dateTime);
		String time = new SimpleDateFormat("mm").format(date);
   		return time;

		
	}
	
public String timeH() throws Throwable {
		
		String dateTimeH = reportDateFormat();
		Date date = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss a").parse(dateTimeH);
		String time2 = new SimpleDateFormat("h").format(date);
        return time2;

		
	}

public String markerTime() throws Throwable {
	
	String dateMarkerTime = reportDateFormat();
	Date date = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss a").parse(dateMarkerTime);
	String marker = new SimpleDateFormat(" a ").format(date);
	return marker;

	
}




public void openPage(String link) throws Throwable {
	
	driver.findElement(By.linkText(link)).click();
}


//public enum GETDATETIME{
	
	//time,date
//}

public String splitStringDate(String dateTime,String type,String separator) throws Throwable {
	String returnValue=null;
	String  stringDate = dateTime;
	String[] parts = stringDate.split(separator);
	String monthHH = parts[0];
	String dayMM = parts[1]; 
	String yearMar = parts[2]; 
	
	
	/*switch(type){
		
	case "time":
		System.out.println("String time changed : "  + monthHH);
		returnValue = monthHH.trim() + yearMar.trim();
				
			break;
	case "date":
		String convertedMonth = returnMonth(monthHH);
		System.out.println("String Month changed to Date: "  + convertedMonth);
		returnValue = convertedMonth.trim() + dayMM.trim();
		break;
	
	}*/
	
	if(type.trim().equalsIgnoreCase("time")){
		monthHH = monthHH.replaceAll("^0*", "");
		System.out.println("String time changed : "  + monthHH);
		returnValue = monthHH.trim()+" "+yearMar.trim();
		
	}else if(type.trim().equalsIgnoreCase("date")){
		
		String convertedMonth = returnMonth(monthHH);
		System.out.println("String Month changed to Date: "  + convertedMonth);
		 
		returnValue = convertedMonth.trim()+" "+dayMM.trim();
	}
	
	return returnValue;
  
}

public String returnMonth(String valueMonth) throws Throwable {
	int position = Integer.parseInt(valueMonth);
	String[] allMonths = {"Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	return (allMonths[position -1]);
	
}


public void apptExist(String dateApptLocal, String timeApptLocal) throws Throwable{
	String newDate;
	String newTime;
	newDate = splitStringDate(dateApptLocal,"date","/");
	newTime = splitStringDate(timeApptLocal,"time",":");
	WebElement div = driver.findElement(By.id("calendarContent"));
	WebElement calendarTable = div.findElement(By.className("Calendar"));
	List<WebElement> row = calendarTable.findElements(By.tagName("tr"));
    for (WebElement value : row) {  
		String rowValue = value.getText();
		if(thExist(value)){
		System.out.println("IN APPTEXIST METHOD:  THIS IS THE TH VALUE "+value.findElement(By.tagName("th")).getText());
		if(rowValue.contains(newDate)){
			System.out.println("IN APPTEXIST METHOD:THIS IS THE EXPECTED ROW ***");
			List<WebElement> tds=value.findElements(By.tagName("td"));
			int rowReturn = getHourTh(calendarTable, newTime);
			System.out.println("IN APPTEXIST METHOD:THIS IS THE ROWRETURN VALUE *---* "+ rowReturn);
			if(divExist(value)){
				 WebElement td= tds.get(rowReturn );
		    System.out.println("IN APPTEXIST METHOD:THIS IS THE TD VALUE IN if --- "+ td.getText());
			System.out.println("IN APPTEXIST METHOD:THIS IS THE  VALUE tagname DIV--- aPPOINTMENT EXIST"+td.findElement(By.tagName("div")).getText());
			WebElement divOpenAppt = td.findElement(By.tagName("div"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			//executor.executeScript("arguments[0].click();", divOpenAppt);
			//appointmentDetails();
			}else {
				 System.out.println("THERE IS NOT DIV AND I DONT KNOW WHYYYY --- ");
			 }
		}
	}
}
	
	
}

public void apptExistAvailability(String timeApptLocal) throws Throwable{
	//String newDate;
	String newTime;
	
	//newDate = splitStringDate(dateApptLocal,"date","/");
	newTime = splitStringDate(timeApptLocal,"time",":");
	String[] arrTime =  splitTime(timeApptLocal,"time",":");
	int timeMin =  Integer.parseInt(arrTime[1]); 
	System.out.println("///THIS IS TIME Minutes Minuteds" + timeMin);
	//String timeNA = timeH();
	int timeComp = Integer.parseInt(arrTime[0]);
    //System.out.println("///THIS IS TIMENA:::: ///" + timeNA);
	//String timeNonptAppt = timeNA + markerTime();
	WebElement div = driver.findElement(By.id("content"));
	WebElement calendarTable = div.findElement(By.className("Calendar"));
	List<WebElement> row = calendarTable.findElements(By.tagName("tr"));
	for (WebElement value : row) {  
		String rowValueAvailability = value.getText();
		System.out.println("///THIS IS THE VALUE FOR ROW IN AVAILABILITY for NON PT APPT///" + rowValueAvailability);
		if(thExist(value)){
		System.out.println("THIS IS THE THEAD VALUE  FOR AVAILABILITY"+value.findElement(By.tagName("th")).getText());
		}//end if th exist
		else{
			
			System.out.println("THese are the VALUES FOR TIME  Non patient " + timeComp + "MIN : "  + timeMin + "MARKER: " + markerTime() );
			if ((timeComp == 5) && (timeMin > 45) && (arrTime[2].trim().equalsIgnoreCase("PM"))) {
				System.out.println("THese are the VALUES FOR  Non patient AND IS IN THE IFFF-+*+-*+-*+-* " ) ;
				
				afterSix();
				if(rowValueAvailability.contains("PINTO, JOSUE")){
					System.out.println("THIS IS THE EXPECTED ROW FOR AVAILABILITY non patient ***");
					List<WebElement> tds=value.findElements(By.tagName("td"));
					int rowReturn = getHourTh(calendarTable, newTime);
					System.out.println("THIS IS THE ROWRETURN VALUE *---* non patient "+ rowReturn);
					if(divExist(value)){
						 WebElement td= tds.get(rowReturn + 2);
						 tdId= rowReturn + 2;
                         String valueApptBttn = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")).getText();
                         System.out.println("THIS IS THE VALUE for VALUEAPPTBTTN */*/ " + valueApptBttn );

				}//
				
			}else {
				
				if(rowValueAvailability.contains("PINTO, JOSUE")){
					System.out.println("THIS IS THE EXPECTED ROW FOR AVAILABILITY non patient ***");
					List<WebElement> tds=value.findElements(By.tagName("td"));
					int rowReturn = getHourTh(calendarTable, newTime);
					System.out.println("THIS IS THE ROWRETURN VALUE *---* non patient "+ rowReturn);
					if(divExist(value)){
						 WebElement td= tds.get(rowReturn + 2);
						 tdId= rowReturn + 2;
                         String valueApptBttn = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")).getText();
                         System.out.println("THIS IS THE VALUE for VALUEAPPTBTTN */*/ " + valueApptBttn );

				}//
				
			}
		
			
			
		}
      }
}
	}
	}
	
public String[] splitTime(String dateTime,String type,String separator) throws Throwable {
	String returnValue=null;
	String  stringDate = dateTime;
	String[] parts = stringDate.split(separator);
	String monthHH = parts[0];
	String dayMM = parts[1]; 
	String yearMar = parts[2]; 
	return parts;
}
	


//On Open Appointment Page date is set up to value
public void selectDate(String apptDate) throws Throwable {
	System.out.println("It is entering in the select date method");
	JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("document.getElementById('ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ctl00_JumpDate').setAttribute('value','"+apptDate+"')");      
	driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ctl00_DateJumpImage']")).click();
	
}



public void allConflictAppointments(String status)throws Throwable {
	boolean valueReturned=false;
	int numberList=0;
	int numberRecords=0;
	
	int i=1; int j=0; int recordId=3; int listId=2;
	
	numberList=numberListConflict();
	numberRecords=numberRecordsConflict();
	
	WebDriverWait wait = new WebDriverWait(driver,20);
	   

	
	do{
		
		do{
			
			if(valueReturned != true){
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+recordId+"]/td[7]/input") ));
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+recordId+"]/td[7]/input")).click();
				valueReturned= apptStatusExist(status);
				recordId++;
				j++;
			System.out.println("VALUE RETURNED: " + valueReturned);
			System.out.println("RECORDID: " + recordId);
			System.out.println("J value: " + j);
			System.out.println("INNER WHILE");
			if(valueReturned==false){
				openPage("Home Page");
			}else{
		           j=numberRecords+1;
		           positionRecord=recordId - 1;
		           System.out.println("J value in ELSE: " + j);
		           System.out.println("POSITION RECORD VALUE: " + positionRecord);
			}
			}
			
				
		}while(numberRecords>j );
		
		if(valueReturned  ){
			positionList=listId - 1;
			System.out.println("POSITION LIST: " + positionList);
			i=numberList + 1;
		}else if(numberList== i ){
			i=numberList + 1;
		}else{
			openPage("Home Page");
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr[1]/td/table/tbody/tr/td["+listId+"]/a") ));
			driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr[1]/td/table/tbody/tr/td["+listId+"]/a")).click();
			recordId=3;
			j=0;
			i++;
			listId++;
			valueReturned=false;
			numberRecords=numberRecordsConflict();
			System.out.println("I value: " + i);
			System.out.println("OUTTER WHILE");
			System.out.println("THIS VALUE IS FROM ELSE listID: " + listId);
			
		}
		
		
	}while(numberList>= i);
		
}

public int numberListConflict()throws Throwable {
	int sizeList=0;
	WebElement apptTable = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities"));
	List<WebElement> rows = apptTable.findElements(By.tagName("tr"));
	WebElement rowTd=rows.get(0);
	List<WebElement> tableTd = rowTd.findElements(By.tagName("td"));
	sizeList=tableTd.size() - 1;
	System.out.println("METHOD NUMBERLISTCONFLICT");
	System.out.println("sizeList: " + sizeList);
	return sizeList;
	
}

public int numberRecordsConflict()throws Throwable {
	System.out.println("beginning of method....METHOD NUMBERRECORDSCONFLICT");
	WebDriverWait wait = new WebDriverWait(driver,20);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities")));
	int sizeList=0;
	WebElement apptTable = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities"));
	List<WebElement> rows = apptTable.findElements(By.tagName("tr"));
	sizeList=rows.size()-3;
	System.out.println("METHOD NUMBERRECORDSCONFLICT");
	System.out.println("sizeList: " + sizeList);
	return sizeList;
	
}


public boolean apptStatusExist(String statusExist){
	boolean value=false;
	int nextRow=0;
	int statusId=2;
	String status=statusExist;
	
	WebElement apptTable = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest"));
	List<WebElement> rows = apptTable.findElements(By.tagName("tr"));
	
	do{
		
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest_ctl0"+statusId+"_lbStatus']")).getText();
		if (attributeValue.trim().contains(status.trim())){
			System.out.println("This is the value for the status in the If:" + attributeValue);
			//driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest_ctl02_lbStatus']")).click();
			nextRow=rows.size() + 1;
			value=true;
		}else{
			
			nextRow++;
			statusId++;
			System.out.println("It is in the else");
			System.out.println("NEXTROW VALUE: " + nextRow);
			System.out.println("STATUSID VALUE: " + statusId);
			value=false;
		}
		
	}while(rows.size()-1> nextRow);
	
	return value;
	
}

//Returns the number of column 
public int apptStatusId(String statusExist){
	int value=0;
	int nextRow=0;
	int statusId=2;
	String status=statusExist;
	
	WebElement apptTable = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest"));
	List<WebElement> rows = apptTable.findElements(By.tagName("tr"));
	
	do{
		
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest_ctl0"+statusId+"_lbStatus']")).getText();
		if (attributeValue.trim().contains(status.trim())){
			System.out.println("This is the value for the status in the If:" + attributeValue);
			//driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest_ctl02_lbStatus']")).click();
			nextRow=rows.size() + 1;
			value=statusId;
		}else{
			
			nextRow++;
			statusId++;
			System.out.println("It is in the else");
			System.out.println("NEXTROW VALUE: " + nextRow);
			System.out.println("STATUSID VALUE: " + statusId);
			
		}
		
	}while(rows.size()-1> nextRow);
	
	return value;
	
}

public void apptStatus(String statusExist){
	
	int nextRow=0;
	int statusId=2;
	String status=statusExist;
	
	WebElement apptTable = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest"));
	List<WebElement> rows = apptTable.findElements(By.tagName("tr"));
	
	do{
		
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest_ctl0"+statusId+"_lbStatus']")).getText();
		if (attributeValue.trim().contains(status.trim())){
			System.out.println("This is the value for the status in the If:" + attributeValue);
			driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest_ctl0"+statusId+"_lbStatus']")).click();
			nextRow=rows.size() + 1;
		}else{
			
			nextRow++;
			statusId++;
			System.out.println("It is in the else");
			System.out.println("NEXTROW VALUE: " + nextRow);
			System.out.println("STATUSID VALUE: " + statusId);
			
		}
		
	}while(rows.size()-1> nextRow);
	
	
	
}




}

