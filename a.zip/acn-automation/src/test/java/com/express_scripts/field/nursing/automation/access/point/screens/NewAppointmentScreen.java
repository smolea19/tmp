package com.express_scripts.field.nursing.automation.access.point.screens;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class NewAppointmentScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(NewAppointmentScreen.class);
	
	@Then("^click on Patient Id link \\(New Appointment Screen\\)$")
	public void clickOnPatientLink() throws Throwable {
		String ptId = AccessPointInputData.Patient.id;
		
		clickLink(ptId);
		
	}

	@Then("^select patient therapies:\"([^\"]*)\"$")
	public void selectPatientTherapy(String therapiesCsv) throws Throwable {
		
		List<String> therapies = new ArrayList<>(Arrays.asList(therapiesCsv.split(",")));
		
		for (String aTherapy : therapies) {
			AccessPointInputData.Appointment.therapies.add(aTherapy.trim());
			clickOnLabel(aTherapy.trim());
		}

	}

	@Then("^Select appointment date and time:\"([^\"]*)\"$")
	public void selectAppointmentDateAndTime(String timeStrParam) throws Throwable {
		
		Calendar cal = buildCalendar(timeStrParam);
		
		AccessPointInputData.Appointment.dateTime = cal.getTime(); 
		
		String timeStrScreen = buildTimeForScreen(cal);
		
		String meridiem = buildAMorPMForScreen(cal);

		LOG.info("Appointment time param : " + timeStrParam);
		LOG.info("Appointment date/time  : " + cal.getTime());
		LOG.info("Appointment time Screen: " + timeStrScreen);
		LOG.info("Appointment meridiem   : " + meridiem);
		
		enterTextIntoTextboxByPartialIdWithJS("tbxStartTime", timeStrScreen);

		selectDropdownBoxByPartialId("ddlMeridiem", meridiem);
	}

	private String buildAMorPMForScreen(Calendar cal) {
		return cal.get(Calendar.AM_PM)==Calendar.AM?"AM":"PM";
	}

	private String buildTimeForScreen(Calendar cal) {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%02d", cal.get(Calendar.HOUR)));
		sb.append(":");
		sb.append(String.format("%02d", cal.get(Calendar.MINUTE)));
		  
		String timeStrScreen = sb.toString();
		return timeStrScreen;
	}

	private Calendar buildCalendar(String timeStr) {
		Calendar cal = Calendar.getInstance();
		
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeStr.split(":")[0]));
		cal.set(Calendar.MINUTE, Integer.parseInt(timeStr.split(":")[1]));
		return cal;
	}

}
