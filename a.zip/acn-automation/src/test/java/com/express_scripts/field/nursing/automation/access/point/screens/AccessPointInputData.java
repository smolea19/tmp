package com.express_scripts.field.nursing.automation.access.point.screens;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Given;

public class AccessPointInputData {
	
	static class Metadata{
		public static boolean pauseEnabled = true;
		public static String scenarioName;
		public static Date executionTimestamp;
		
		private static SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd_HHmmss");
		public static String getExecutionId(){
			return sdf.format(executionTimestamp);
		}
	}
	static class Login{
		public static String accessPointURL;
		public static String userId;
		public static String password;
	}
	
	static class Patient{
		public static String id;
		public static String lastName;
		public static String firstName;
		public static String abbrev;
		
	}

	static class Nurse{
		public static String id;
		public static String name;
	}

	static class Appointment{
		public static Date date;
		public static Date conflictDate;
		public static Date dateTime;
		public static List<String> therapies = new ArrayList<>();
		public static CharSequence previousApptId;
	}
	
	@Given("^pause set as false$")
	public void pauseenabledFalse() throws Throwable {
	    Metadata.pauseEnabled = false;
	    BaseTesting.pauseEnabled = Metadata.pauseEnabled;
	}
	
	@Given("^the Patient Id:\"([^\"]*)\"$")
	public void storePatientId(String param) throws Throwable {
		Patient.id = param;
	}

	@Given("^the Scenario Name:\"([^\"]*)\"$")
	public void storeScenarioName(String param) throws Throwable {
		Metadata.scenarioName = param;
		Metadata.executionTimestamp = new Date();
	}

	@Given("^the Nurse Id:\"([^\"]*)\"$")
	public void storeNurseId(String param) throws Throwable {
		Nurse.id = param;
	}
	
	@Given("^the Appointment Date:\"([^\"]*)\"$")
	public void storeAppointmentDate(String param) throws Throwable {
		if ("Today".equalsIgnoreCase(param)){
			Appointment.date = new Date();
		}else{
			Appointment.date = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(param);
		}
		
	}
	
	@Given("^the previous appointment id:\"([^\"]*)\"$")
	public void thePreviousAppointmentId(String param) throws Throwable {
		Appointment.previousApptId =param;
	}
	
	
}
