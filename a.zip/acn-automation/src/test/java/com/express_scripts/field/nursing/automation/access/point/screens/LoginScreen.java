package com.express_scripts.field.nursing.automation.access.point.screens;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(LoginScreen.class);
	
	@Given("^the URL:\"([^\"]*)\"$")
	public void the_URL(String URL) throws Throwable {
		AccessPointInputData.Login.accessPointURL = URL;
		LOG.info("Opening: " + URL);
	   		
		driver.get(URL);
		//driver.manage().window().maximize();
	}

	@Then("^enter userid:\"([^\"]*)\"$")
	public void user_enter_userid(String user) throws Throwable {
		AccessPointInputData.Login.userId = user;
		
		enterTextIntoTextbox("User Name:", user);
		
	}



	@Then("^enter password:\"([^\"]*)\"$")
	public void password(String pwd) throws Throwable {
		AccessPointInputData.Login.password = pwd;
		
		enterTextIntoTextbox("Password:", pwd);
	}

}
