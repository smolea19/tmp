package com.express_scripts.field.nursing.automation.access.point.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.jsoup.examples.HtmlToPlainText;
import org.jsoup.nodes.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;

import com.express_scripts.field.nursing.automation.access.point.screens.AccessPointInputData;


public class BaseTesting {
	private static final Logger LOG = LogManager.getLogger(BaseTesting.class);
	
	List<WebElement> highlightedElements = new ArrayList<>();
	
	protected WebDriver driver;

	public static boolean pauseEnabled = true;
	
	
	
	public BaseTesting() {
		this.driver = FirefoxDriverFactory.getInstance();
	}
	
	protected void enterTextIntoTextbox(String fieldLabel, String keys) {
		int MAX_ATTEMPTS = 3;
		enterTextIntoTextbox(fieldLabel, keys, MAX_ATTEMPTS);
	}
	
	private void selectDropdownBox(String xPath, String text) {
		WebElement webElement = driver.findElement(By.xpath(xPath));
		highlight(webElement);
		Select dropdown = new Select(webElement);
		dropdown.selectByVisibleText(text);
		postDataEntry();
	}
	protected void selectDropdownBoxByPartialId(String textboxId, String text) {
		String xPath = String.format("//select[contains(@id,'%s')]", textboxId);
		
		selectDropdownBox(xPath, text);
		
	}
	protected String readLabelByPartialId(String textboxId) {
		WebElement webElement = getWebElementByPartialId("*", textboxId);
		return webElement.getText();
	}
	protected String readTextboxByPartialId(String textboxId) {
		WebElement webElement = getWebElementByPartialId(textboxId);
		return webElement.getAttribute("value");
	}
	protected void enterTextIntoTextboxByPartialId(String textboxId, String keys) {
		WebElement webElement = getWebElementByPartialId(textboxId);
		enterTextIntoTextbox(webElement, keys);
	}

	private WebElement getWebElementByPartialId(String type, String partialId) {
		String xPath = String.format("//"+type+"[contains(@id,'%s')]", partialId);
		WebElement webElement = driver.findElement(By.xpath(xPath));
		return webElement;
	}
	private WebElement getWebElementByPartialId(String partialId) {
		return getWebElementByPartialId("input",  partialId);
	}
	protected void checkCheckboxByPartialId(String checkboxId) {
		WebElement webElement = getWebElementByPartialId(checkboxId);
		webElement.click();
	}
	protected void enterTextIntoTextboxByPartialIdWithJS(String textboxId, String keys) {
		WebElement webElement = getWebElementByPartialId(textboxId);
		
		highlight(webElement);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		js.executeScript(
				"arguments[0].value=arguments[1];",
				webElement, keys);
		
		postDataEntry();

	}
	private void enterTextIntoTextbox(WebElement webElement, String keys) {
		highlight(webElement);
		webElement.sendKeys(keys);
		postDataEntry();
	}

	protected void clickOnLabel(String therapy) {
		click(By.xpath("//label[text()='"+therapy+"']/../input"));
	}

	protected void waitSeconds(int seconds) {
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
	}
	
	public void waitForTextToAppear(final String partialId) {
	    org.openqa.selenium.support.ui.WebDriverWait wait = new org.openqa.selenium.support.ui.WebDriverWait(driver,30);
	    wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return readTextboxByPartialId(partialId).length() != 0;
            }
        });
	}


	protected void enterTextIntoTextbox(String fieldLabel, String keys, int MAX_ATTEMPTS) {
		WebElement webElement = null;
		
		
		String parent = "/..";
		String currentParent = parent;
		int attempt = 0;
		String xPath;
		do{
			try {
				xPath = String.format("//*[contains(text(), '%s')]%s//input", fieldLabel, currentParent);
				webElement = driver.findElement(By.xpath(xPath));
			} catch (NoSuchElementException e) {
				currentParent +=parent;
			}
		} while (webElement == null && ++attempt < MAX_ATTEMPTS);
		
		
		enterTextIntoTextbox(webElement, keys);
	}
	
	public void highlight(WebElement webElement) {
		if ("checkbox".equalsIgnoreCase(webElement.getAttribute("type"))){
			webElement = webElement.findElement(By.xpath("./..")); 
		}
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(
				"arguments[0].setAttribute('style', arguments[1]);",
				webElement, "border: 3px solid blue;");

		//webElement.getAttribute("innerHTML")
		//js.executeScript("arguments[0].scrollIntoView(true);",webElement);
		scrollTo(webElement);
		
		highlightedElements.add(webElement);
	}
	
	public void scrollTo(String text){
		String xPath = String.format("//*[contains(text(),'%s')]", text);
		scrollTo(By.xpath(xPath));
	}
	private void scrollTo(By xpath) {
		scrollTo(driver.findElement(xpath));
		
	}

	public void scrollTo(WebElement webElement){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",webElement);
	}
	
	private void postDataEntry() {
		//long milliseconds = 0;
		//long milliseconds = 500;
		long milliseconds = 1000;
		sleepMilliseconds(milliseconds);
		
	}
	protected void sleepMilliseconds(long milliseconds) {
		if (pauseEnabled ){
			try {
				Thread.sleep(milliseconds);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	protected String formatDate(Date date, String format){
		return new SimpleDateFormat(format).format(date);
	}

	protected void _takeScreenshot(Path fileNamePath) throws IOException {
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, fileNamePath.toFile());
		
		resetHighlightedElements();
	}

	
	private void resetHighlightedElements() {
		for (WebElement element : highlightedElements) {
			resetHighlight(element);
		}
	}
	private void resetHighlight(WebElement element) {
		for (int i = 0; i < 2; i++) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			try {
				js.executeScript(
						"arguments[0].setAttribute('style', arguments[1]);",
						element, "");
			} catch (WebDriverException e) {
				LOG.warn(e.getMessage());
			}
		}
	}
	
	protected WebElement sendKeys(By by, String text){
		WebElement webElement = driver.findElement(by);
		webElement.sendKeys(text);
		return webElement;
	}
	protected String getAttribute(By by, String attribute){
		WebElement webElement = driver.findElement(by);
		return webElement.getAttribute(attribute);
	}

	protected void switchToFrame(String frame) {
		driver.switchTo().defaultContent();
		WebElement fr = driver.findElement(By.id(frame));
        driver.switchTo().frame(fr);
	}

	protected WebElement clickButton(String value){
		String xPath = String.format("//input[contains(@value,'%s')]", value);
		return click(By.xpath(xPath));
	}
	protected WebElement clickLink(String link){
		return click(By.linkText(link));
	}
	
	protected WebElement clickByXPath(String xPath){
		return click(By.xpath(xPath));
	}
	private WebElement click(By by){
		WebElement webElement = driver.findElement(by);
		highlight(webElement);
		postDataEntry();
		webElement.click();
		return webElement;
	}

	protected String readField(String fieldName, By xpath){
		String innerHTMLPlainText = getInnerHTMLAsPlainText(xpath);
		
		LOG.info(">>> "+fieldName + ":\t" + innerHTMLPlainText);
		
		return innerHTMLPlainText;
	}
	
	protected WebElement getWebElement(By xpath) {
		WebElement webElement = null;

		webElement = driver.findElement(xpath);

		return webElement;
	}

	protected String getTextFromField(By xpath) {
		String textHtml;
		try {
			textHtml = getWebElement(xpath).getText();
		} catch (NoSuchElementException e) {
			textHtml = "NoSuchElementException";
		}

		return textHtml;
	}

	protected String getInnerHtmlFromField(By xpath) {
		String textHtml;
		try {
			textHtml = getWebElement(xpath).getAttribute("innerHTML");
		} catch (NoSuchElementException e) {
			textHtml = "NoSuchElementException";
		}
		
		return textHtml;
	}
	
	protected String getInnerHTMLAsPlainText(By xpath){
		HtmlToPlainText htmlToPlainText = new HtmlToPlainText();
		
		Element element = new Element("</x>");
		//element = element.append(getTextFromField(xpath));
		element = element.append(getInnerHtmlFromField(xpath));
		String plainText = htmlToPlainText.getPlainText(element).trim();
		
		//System.out.println("plainText: " + plainText);

		return plainText;
	}

}
