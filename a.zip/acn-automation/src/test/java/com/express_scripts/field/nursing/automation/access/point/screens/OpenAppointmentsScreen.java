package com.express_scripts.field.nursing.automation.access.point.screens;

import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class OpenAppointmentsScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(OpenAppointmentsScreen.class);
	
	@Then("^click on open appointment$")
	public void clickOnOpenAppointment() throws Throwable {
		Date newDate = AccessPointInputData.Appointment.dateTime;
		String date = formatDate(newDate, "MMM d");
		String time = formatDate(newDate, "h a");
		String patientAbbrev = AccessPointInputData.Patient.abbrev; 
		String therapy = AccessPointInputData.Appointment.therapies.get(0);
		
		clickOnOpenAppointment(date, time, patientAbbrev, therapy);
		
		switchToFrame("PopupFrame0");
		
	}
	
	private void clickOnOpenAppointment(String date, String time, String patientAbbrev, String therapy) {
		
		String dateXpath = String.format("//*[@id='calendarContent']/*//span[contains(text(),'%s')]/ancestor::tr", date);
		String rowIndex = getAttribute(By.xpath(dateXpath),"rowIndex");
		
		String timeXpath = String.format("//*[@id='calendarContent']//div/table/thead/tr/th[contains(text(),'%s')]", time);
		String cellIndex = getAttribute(By.xpath(timeXpath), "cellIndex");
		
		String apptXPath = String.format("//*[@id='calendarContent']/*//tr[%s]/td[%s]/*//span[contains(text(), '%s') and contains(text(), '%s')]/ancestor::div[position()=1]", rowIndex, cellIndex, patientAbbrev, therapy);
		
		LOG.info("apptXPath: " + apptXPath);
		
		clickByXPath(apptXPath);
		
	}




}
