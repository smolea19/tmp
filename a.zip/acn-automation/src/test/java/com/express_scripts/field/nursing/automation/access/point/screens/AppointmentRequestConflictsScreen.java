package com.express_scripts.field.nursing.automation.access.point.screens;

import java.text.SimpleDateFormat;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class AppointmentRequestConflictsScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(AppointmentRequestConflictsScreen.class);
	
	public AppointmentRequestConflictsScreen() {
		LOG.info("Default constructor");
	}
	
	@Then("^click on requested appointment trash icon$")
	public void clickOnTrashcanIcon() throws Throwable {
		String appointmentDate =  new SimpleDateFormat("h:mm").format(AccessPointInputData.Appointment.conflictDate);
		String xPath = String.format("//*[contains(text(),'%s')]/ancestor::tr//img[contains(@src, 'trashcan')]/ancestor::a", appointmentDate);
	    clickByXPath(xPath);
	}
	
	@Then("^click on delete request:\"([^\"]*)\"$")
	public void clickOnDeleteRequestYes(String button) throws Throwable {
		
		switchToFrame("PopupFrame0");
		
		clickButton(button);
	}
}
