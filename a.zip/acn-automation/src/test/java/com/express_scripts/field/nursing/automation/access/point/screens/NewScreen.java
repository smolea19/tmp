package com.express_scripts.field.nursing.automation.access.point.screens;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

public class NewScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(NewScreen.class);
	
	public NewScreen() {
		LOG.info("Default constructor");
	}
	

}
