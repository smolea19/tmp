package com.express_scripts.field.nursing.automation.access.point.screens;

import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class NurseAvailabilityScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(NurseAvailabilityScreen.class);
	
	@Then("^open assigned appointment$")
	public void open_appointment() throws Throwable {
		Date newDate = AccessPointInputData.Appointment.dateTime;
		String time = formatDate(newDate, "h a");
		String patientAbbrev = AccessPointInputData.Patient.abbrev; 
		String therapy = AccessPointInputData.Appointment.therapies.get(0);
		String nurseName = "NURSE, SERGIO";
		
		clickOnAssignedAppointment(nurseName, time, patientAbbrev, therapy);
		
		//_assignNurse(newDate);
		
	}
	
	private void clickOnAssignedAppointment(String nurseName, String time, String patientAbbrev, String therapy) {
		
		String dateXpath = String.format("//*[@id='calendarContent']/*//b[contains(text(),'%s')]/ancestor::tr", nurseName);
		String rowId = getAttribute(By.xpath(dateXpath),"id");
		
		String timeXpath = String.format("//*[@id='calendarContent']//div/table/thead/tr/th[contains(text(),'%s')]", time);
		int cellIndex = Integer.parseInt(getAttribute(By.xpath(timeXpath), "cellIndex"))+2;
		
//		String apptXPath = String.format("//*[@id='calendarContent']/*//tr[%s]/td[%s]/*//span[contains(text(), '%s') and contains(text(), '%s')]/ancestor::div[position()=1]", rowIndex, cellIndex, patientAbbrev, therapy);
		String apptXPath = String.format("//*[@id='%s']/td[%d]//*/span[contains(text(), '%s') and contains(text(), '%s')]/ancestor::div[position()=1]", rowId, cellIndex, patientAbbrev, therapy);
		
		LOG.info("apptXPath: " + apptXPath);
		
		clickByXPath(apptXPath);
		
	}

}
