package com.express_scripts.field.nursing.automation.access.point.screens;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class OverrideFunctionScreen extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(OverrideFunctionScreen.class);
	
	
	@Then("^enter Nurse Id$")
	public void enterNurse() throws Throwable {
		LOG.info("Assigning Nurse...");
		
		switchToFrame("PopupFrame1");
		
		String nurseId = AccessPointInputData.Nurse.id;
		
		enterTextIntoTextboxByPartialId("tbxNurseId", nurseId);

	}

	@Then("^click on found Nurse$")
	public void clickOnFoundNurse() throws Throwable {
		String nurseId = AccessPointInputData.Nurse.id;
		
		clickLink(nurseId);
		
		AccessPointInputData.Nurse.name = readLabelByPartialId("lbltableNurseName");
		
		//switchToFrame("PopupFrame1");
		
	}
}
