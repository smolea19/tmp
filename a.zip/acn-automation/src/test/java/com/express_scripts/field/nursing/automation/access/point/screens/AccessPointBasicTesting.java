package com.express_scripts.field.nursing.automation.access.point.screens;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.express_scripts.field.nursing.automation.access.point.utils.AccessPointSupport;

import cucumber.api.java.After;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AccessPointBasicTesting extends AccessPointSupport{
	
	private static final Logger LOG = LogManager.getLogger(AccessPointBasicTesting.class);
	
	
	
	@When("^user click on Nurse Time Administration$")
	public void user_click_on_Nurse_Time_Administration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement linkNurseTimeAdministration = driver.findElement(By.linkText("Nurse Time Administration"));
		linkNurseTimeAdministration.click();
		WebElement btnAddNurse = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_btnAddNurse"));
		btnAddNurse.click();
	}


	@When("^user Add a nurse:\"([^\"]*)\"$")
	public void user_Add_a_nurse(String nurseId) throws Throwable {
	    
		WebElement fr = driver.findElement(By.id("PopupFrame0"));
    	driver.switchTo().frame(fr);
		WebElement txtNurseId = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_tbxNurseId"));
		txtNurseId.sendKeys(nurseId);
		driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnSearch")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_lvSearchResults_ctl02_cbNurseId']")).click(); 
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnAddNurse']")).click();
		
	}

	
	@When("^add AppointmentType:\"([^\"]*)\"$")
	public void add_AppointmentType(String apptType) throws Throwable {
	     
		driver.switchTo().defaultContent();
		WebElement selectElement = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlAppointmentType"));
		Select dropdown = new Select(selectElement);
		dropdown.selectByVisibleText(apptType);
		driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxDuration")).sendKeys("1");
		String time = timeHHMM();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartTime').value='"+time+"'");
		String marker = markerTime();
		if (marker.trim().equals(pm)){
			WebElement selectMarker = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem"));
			Select dropdownMarker = new Select(selectMarker);
			dropdownMarker.selectByVisibleText("PM");
			
		}
		driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_btnCreateApp")).click();
	}

	@Then("^appointment should be created on Nurse Availability for Appointment Type:\"([^\"]*)\"$")
	public void appointment_should_be_created_on_Nurse_Availability_for_Appointment_Type(String appointmentType) throws Throwable {
	    
		int timeMin =  Integer.parseInt(timeMM()); 
		System.out.println("///THIS IS TIME Minutes Minuteds" + timeMin);
		String timeNA = timeH();
		int timeComp = Integer.parseInt(timeNA);
	    System.out.println("///THIS IS TIMENA:::: ///" + timeNA);
		String timeNonptAppt = timeNA + markerTime();
		WebElement div = driver.findElement(By.id("content"));
		WebElement calendarTable = div.findElement(By.className("Calendar"));
		List<WebElement> row = calendarTable.findElements(By.tagName("tr"));
		for (WebElement value : row) {  
			String rowValueAvailability = value.getText();
			System.out.println("///THIS IS THE VALUE FOR ROW IN AVAILABILITY for NON PT APPT///" + rowValueAvailability);
			if(thExist(value)){
			System.out.println("THIS IS THE THEAD VALUE  FOR AVAILABILITY"+value.findElement(By.tagName("th")).getText());
			}//end if th exist
			else{
				
				System.out.println("THese are the VALUES FOR TIME  Non patient " + timeComp + "MIN : "  + timeMin + "MARKER: " + markerTime() );
				if ((timeComp == 2) && (timeMin > 19) && (markerTime().trim().equalsIgnoreCase("PM"))) {
					System.out.println("THese are the VALUES FOR  Non patient AND IS IN THE IFFF-+*+-*+-*+-* " ) ;
					
					afterSix();
					if(rowValueAvailability.contains("PINTO, JOSUE")){
						System.out.println("THIS IS THE EXPECTED ROW FOR AVAILABILITY non patient ***");
						List<WebElement> tds=value.findElements(By.tagName("td"));
						int rowReturn = getHourTh(calendarTable, timeNonptAppt);
						System.out.println("THIS IS THE ROWRETURN VALUE *---* non patient "+ rowReturn);
						if(divExist(value)){
							 WebElement td= tds.get(rowReturn + 2);
							 tdId= rowReturn + 2;
	                         String valueApptBttn = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")).getText();
	                         System.out.println("THIS IS THE VALUE for VALUEAPPTBTTN */*/ " + valueApptBttn );
							 if (appointmentType.trim().equalsIgnoreCase(valueApptBttn.trim())) {
								    WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")); 
									//WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td[7]/table/tbody/tr/td/div/span[2]/span")); 
									System.out.println("THIS IS THE VALUE FOR TDID in the first confirmation --- " + tdId);
									bttnApptAvailability.click();
							        //appDetail_ConfirmAppointment();
							 }
						 }else {
							 System.out.println("THERE IS NOT DIV AND I DONT KNOW WHYYYY --- ");
						 }
					}//
					
				}else {
					
					if(rowValueAvailability.contains("PINTO, JOSUE")){
						System.out.println("THIS IS THE EXPECTED ROW FOR AVAILABILITY non patient ***");
						List<WebElement> tds=value.findElements(By.tagName("td"));
						int rowReturn = getHourTh(calendarTable, timeNonptAppt);
						System.out.println("THIS IS THE ROWRETURN VALUE *---* non patient "+ rowReturn);
						if(divExist(value)){
							 WebElement td= tds.get(rowReturn + 2);
							 tdId= rowReturn + 2;
	                         String valueApptBttn = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")).getText();
	                         System.out.println("THIS IS THE VALUE for VALUEAPPTBTTN */*/ " + valueApptBttn );
							 if (appointmentType.trim().equalsIgnoreCase(valueApptBttn.trim())) {
								    WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td["+tdId+"]/table/tbody/tr/td/div/span[2]/span")); 
									//WebElement bttnApptAvailability = driver.findElement(By.xpath(".//*[@id='tr1354669']/td[7]/table/tbody/tr/td/div/span[2]/span")); 
									System.out.println("THIS IS THE VALUE FOR TDID in the first confirmation --- " + tdId);
									bttnApptAvailability.click();
									break;
							        //appDetail_ConfirmAppointment();
							 }
						 }else {
							 System.out.println("THERE IS NOT DIV AND I DONT KNOW WHYYYY --- ");
						 }
					}//
					
				}
			
				
				
			}
          }
	}

	
	@When("^User open Edit Nurse Time Administration$")
	public void user_open_Edit_Nurse_Time_Administration() throws Throwable {
	    		
		switchFrame();
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnEdit']")).click();
	}

	
	@Then("^user should be able to edit appointment Date:\"([^\"]*)\" Time:\"([^\"]*)\" Appt Type:\"([^\"]*)\"$")
	public void user_should_be_able_to_edit_appointment_Date_Time_Appt_Type(String arg1, String time, String apptType) throws Throwable {
	    
		switchToFrame1();
		WebDriverWait wait = new WebDriverWait(driver,20);
 	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_EditNonPatientTimeControl_ddlAppointmentType") ));
		WebElement selectElement = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_EditNonPatientTimeControl_ddlAppointmentType"));
		Select dropdown = new Select(selectElement);
		dropdown.selectByVisibleText(apptType);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_EditNonPatientTimeControl_tbxStartTime').value='"+time+"'");
		WebElement selectReason = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_EditNonPatientTimeControl_ddlReasonCode"));
		Select dropdownReason = new Select(selectReason);
		dropdownReason.selectByVisibleText("Other");
		WebElement selectMarker = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_EditNonPatientTimeControl_ddlMeridiem"));
		Select dropdownMarker = new Select(selectMarker);
		dropdownMarker.selectByVisibleText("AM");
	}
	
	
	
	@Then("^save new information entered$")
	public void save_new_information_entered() throws Throwable {
	    
		driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_EditNonPatientTimeControl_btnCreateApp")).click();
		WebDriverWait wait = new WebDriverWait(driver,50);
 	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ctl00_MenuContentPlaceHolder_SiteMapPath1") ));
 	   driver.switchTo().defaultContent();
		
	}

	
	@When("^Home Page is displayed place pointer on Therapy Section:\"([^\"]*)\"$")
	public void home_Page_is_displayed_place_pointer_on_Therapy_Section(String sectionTitle) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_NextTherapyDefferentControl_lblTitle']")).getText();
		if (attributeValue.trim().contains(sectionTitle.trim())){
			System.out.println("This is the value for the Title section within the If:" + attributeValue);
			
		}
	}

	@When("^select a conflict  Appointment Therapy for resolution$")
	public void select_a_conflict_Appointment_Therapy_for_resolution() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_NextTherapyDefferentControl_ctl00_lnkActApptDiferent_gvLinkActivities']/tbody/tr[2]/td[6]/input")).click();
	}

	@Then("^Page:\"([^\"]*)\" should be opened so information is displayed$")
	public void page_should_be_opened_so_information_is_displayed(String pageTitle) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String time=null;
		String marker=null;
		
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_lblTitle']")).getText();
		if (attributeValue.trim().contains(pageTitle.trim())){
			System.out.println("This is the value for the Title in the If:" + attributeValue);
			
		}
		
		dateApptThe = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartDate']")).getAttribute("value");
		System.out.println("Appointment date information from get attribute" + dateApptThe);
		time = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartTime']")).getAttribute("value");
		System.out.println("Appointment date information from get attribute" + time);
		//marker = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem']")).getAttribute("selected");
		Select dropdown = new Select(driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem']")));
		WebElement option = dropdown.getFirstSelectedOption();
		marker = option.getText();
		System.out.println("Appointment date information from get attribute" + marker);
		timeApptThe=time+":"+marker;
		//String val=splitStringDate(timeApptLoc,"time",":");
		//System.out.println("VALOR DE TIME RETURNED: " + val);
	}

	@Then("^appointment therapy information is saved$")
	public void appointment_therapy_information_is_saved() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_btnSubmit']")).click();
	}

	@Then("^go to Page:\"([^\"]*)\" to look for appointment therapy$")
	public void go_to_Page_to_look_for_appointment_therapy(String title) throws Throwable {
		String pageTitle = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_MenuContentPlaceHolder_SiteMapPath1']/span")).getText();
		System.out.println("Title from the last method : " + pageTitle);
		if (pageTitle.trim().equalsIgnoreCase(title.trim())){ 
			
			System.out.println("Title from the last method : " + pageTitle);
		}
	}

	@Then("^verify appointment therapy is created$")
	public void verify_appointment_therapy_is_created() throws Throwable {
		openPage("Open Appointments");
	    selectDate(dateApptThe);
	    apptExist(dateApptThe,timeApptThe);
	}


	//**Conflict Location**


	@When("^Home Page is displayed place pointer on Section:\"([^\"]*)\"$")
	public void home_Page_is_displayed_place_pointer_on_Section(String sectionTitle) throws Throwable {

		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_LocationUnkownControl_lblTitle']")).getText();
		if (attributeValue.trim().contains(sectionTitle.trim())){
			System.out.println("This is the value for the Title section within the If:" + attributeValue);
			
		}
		
	}


	@When("^select an Appointment for resolution$")
	public void select_an_Appointment_for_resolution() throws Throwable {

	 driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_LocationUnkownControl_ctl00_lnkActLocationUnknown_gvLinkActivities']/tbody/tr[2]/td[7]/input")).click();
	}


	@Then("^Page:\"([^\"]*)\" should be opened$")
	public void page_should_be_opened(String pageTitle) throws Throwable {
		
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_lblTitle']")).getText();
		if (attributeValue.trim().contains(pageTitle.trim())){
			System.out.println("This is the value for the Title in the If:" + attributeValue);
			
		}
	}


	@Then("^Street_Addresses:\"([^\"]*)\" City:\"([^\"]*)\" State:\"([^\"]*)\" Zip:\"([^\"]*)\" will be Override$")
	public void street_addresses_City_State_Zip_will_be_Override(String add, String city, String state, String zipCode) throws Throwable {
	  
		String time = null;
		String marker=null;
		
		
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxAddressLine1']")).sendKeys(add);
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxCity']")).sendKeys(city);
		WebElement selectState = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlState"));
		Select dropdownState = new Select(selectState);
		dropdownState.selectByVisibleText(state);
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxZip']")).sendKeys();
		JavascriptExecutor js = (JavascriptExecutor) driver;
	  js.executeScript("document.getElementById('ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxZip').value='"+zipCode+"'");
	  
	  dateApptLoc = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartDate']")).getAttribute("value");
		System.out.println("Appointment date information from get attribute" + dateApptLoc);
		time = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartTime']")).getAttribute("value");
		System.out.println("Appointment date information from get attribute" + time);
		//marker = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem']")).getAttribute("selected");
		Select dropdown = new Select(driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem']")));
		WebElement option = dropdown.getFirstSelectedOption();
		marker = option.getText();
		System.out.println("Appointment date information from get attribute" + marker);
		timeApptLoc=time+":"+marker;
		//String val=splitStringDate(timeApptLoc,"time",":");
		//System.out.println("VALOR DE TIME RETURNED: " + val);

	}


	@Then("^information is saved$")
	public void information_is_saved() throws Throwable {
	 
		driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_btnSubmit']")).click();
	}


	@Then("^go to Page:\"([^\"]*)\"$")
	public void go_to_Page(String title) throws Throwable {

		String pageTitle = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_MenuContentPlaceHolder_SiteMapPath1']/span")).getText();
		System.out.println("Title from the last method : " + pageTitle);
		if (pageTitle.trim().equalsIgnoreCase(title.trim())){ 
			
			System.out.println("Title from the last method : " + pageTitle);
		}
		
	}


	@Then("^verify appointment is created$")
	public void verify_appointment_is_created() throws Throwable {

	   openPage("Open Appointments");
	   selectDate(dateApptLoc);
	   apptExist(dateApptLoc,timeApptLoc);
	   
	}

	//**Conflict Time**

	@When("^Home Page is displayed place pointer on Time Section:\"([^\"]*)\"$")
	public void home_Page_is_displayed_place_pointer_on_Time_Section(String sectionTitle) throws Throwable {
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_lblTitle']")).getText();
		if (attributeValue.trim().contains(sectionTitle.trim())){
			System.out.println("This is the value for the Title section within the If:" + attributeValue);
		}
	}

	@Then("^select a conflict Appointment time for resolution with status:\"([^\"]*)\"$")
	public void select_a_conflict_Appointment_time_for_resolution_with_status(String statusResolution) throws Throwable {
		allConflictAppointments(statusResolution);
		if(positionList!=0 && positionRecord!=0){
			openPage("Home Page");
			if(positionList==1){			                                      
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+positionRecord+"]/td[7]/input")).click();
			}else{
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr[1]/td/table/tbody/tr/td["+positionList+"]/a")).click();
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+positionRecord+"]/td[7]/input")).click();
			}
			
			
		}
	}

	@Then("^it is open Page:\"([^\"]*)\"  so conflict appointments time are displayed$")
	public void it_is_open_Page_so_conflict_appointments_time_are_displayed(String pageTitle) throws Throwable {
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_lblTitle']")).getText();
		if (attributeValue.trim().contains(pageTitle.trim())){
			System.out.println("This is the value for the Title in the If:" + attributeValue);
			
		}
	}

	@When("^user click on appointment with Status:\"([^\"]*)\"$")
	public void user_click_on_appointment_with_Status(String status) throws Throwable {
		apptStatus(status);
	}

	@Then("^it is open Page:\"([^\"]*)\" with appointment time information displayed$")
	public void it_is_open_Page_with_appointment_time_information_displayed(String pageTitle) throws Throwable {
		String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_lblTitle']")).getText();
		if (attributeValue.trim().contains(pageTitle.trim())){
			System.out.println("This is the value for the Title in the If:" + attributeValue);
			
		}
	}

	@Then("^Start_Time:\"([^\"]*)\" will be overridden$")
	public void start_time_will_be_overridden(String newHour) throws Throwable {
		String time = null;
		String marker=null;
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartTime').value='"+newHour+"'");

		    dateApptTime = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartDate']")).getAttribute("value");
			System.out.println("Appointment date information from get attribute" + dateApptLoc);
			time = newHour; //driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_tbxStartTime']")).getAttribute("value");
			System.out.println("Appointment date information from get attribute" + time);
			//marker = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem']")).getAttribute("selected");
			Select dropdown = new Select(driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_ddlMeridiem']")));
			WebElement option = dropdown.getFirstSelectedOption();
			marker = option.getText();
			System.out.println("Appointment date information from get attribute" + marker);
			timeApptTime=time+":"+marker;
	}

	@Then("^information is saved for Appointment Time$")
	public void information_is_saved_for_Appointment_Time() throws Throwable {
	    driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ScheduleNonPatientTimeControl_ctl00_btnSubmit")).click();
	}

	@Then("^verify appointment Time is updated correctly$")
	public void verify_appointment_Time_is_updated_correctly() throws Throwable {
		System.out.println();
	/*	
		if(status!="OPEN"){		
			   openPage("Nurse Availability");
			   selectDate(dateApptTime);
			   apptExist(dateApptTime,timeApptTime);
		}else{		
		   openPage("Open Appointments");
		   selectDate(dateApptTime);
		   apptExist(dateApptTime,timeApptTime);
		}
	}

	@Then("^return to Page:\"([^\"]*)\"$")
	public void return_to_Page(String pageTitle) throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver,20);
		if(positionList!=0 && positionRecord!=0){
			openPage("Home Page");
			if(positionList==1){		
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+positionRecord+"]/td[7]/input") ));
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+positionRecord+"]/td[7]/input")).click();
				String attributeValue = driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_lblTitle']")).getText();
				if (attributeValue.trim().contains(pageTitle.trim())){
					System.out.println("This is the value for the Title in the If:" + attributeValue);
					
				}
			}else{
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr[1]/td/table/tbody/tr/td["+positionList+"]/a")).click();
				driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_MultipleAppointmentsControl_ctl00_lnkActMultAppts_gvLinkActivities']/tbody/tr["+positionRecord+"]/td[7]/input")).click();
				String attributeValue = driver.findElement(By.xpath(".//*[@id='.//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_lblTitle']']")).getText();
				if (attributeValue.trim().contains(pageTitle.trim())){
					System.out.println("This is the value for the Title in the If:" + attributeValue);
					
				}
			}
			
			
		}*/
	    
	}

	@Then("^delete appointment with status:\"([^\"]*)\"$")
	public void delete_appointment_with_status(String status) throws Throwable {
		int columnId=0;
		columnId=apptStatusId(status);
		if(columnId!=0){
			driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1NS_ApptRequest_gvApptRequest']/tbody/tr["+columnId+"]/td[5]/a/img")).click();
			switchFrame();
			driver.findElement(By.xpath(".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1EM_btnDeleteRequest']")).click();
		}
	   
	}

	
	@After()
	public void after (){
		
		//driver.close();
		//driver.quit();
	}


}
