package com.express_scripts.field.nursing.automation.access.point.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;

public class FirefoxDriverFactory {
	private static WebDriver driver;
	
	private FirefoxDriverFactory() {
		//Empty constructor
	}
	
	public static WebDriver getInstance(){
		if (driver == null){
			
		
			driver = new FirefoxDriver();
		}
		
		return driver;
	}
}
