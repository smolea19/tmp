package com.express_scripts.field.nursing.automation.access.point.screens;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.access.point.properties.AutomationProperties;
import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;
import com.express_scripts.field.nursing.common.files.text.TextFileUtils;
import com.express_scripts.field.nursing.common.sqlserver.SQLServerClient;

import cucumber.api.java.en.Then;

public class AccessPointDB extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(AccessPointDB.class);
	
	private SQLServerClient sqlServerClient;
	
	public AccessPointDB() {
		sqlServerClient = new SQLServerClient();
	}
	
	@Then("^clean up today's appointments$")
	public void cleanUpTodaysAppointments() throws Throwable {
		LOG.info("Wiping out previous appts...");

		String patientId = AccessPointInputData.Patient.id;
		String nurseId = AccessPointInputData.Nurse.id;
		String currentScheduleDateStr = new SimpleDateFormat("YYYY-MM-dd").format(new Date());
		
		wipeoutTodaysAppointmentsByPatientAndDate(patientId, currentScheduleDateStr);
		
		wipeoutTodaysAppointmentsByNurseIdAndDate(nurseId, currentScheduleDateStr);
				
	}

	private void wipeoutTodaysAppointmentsByNurseIdAndDate(String nurseId, String currentScheduleDateStr) throws Exception {
		Path updateSqlFile = Paths.get("etc\\sql\\accessPoint\\wipeoutTodaysAppointmentsByNurseIdAndDate.sql");
		String updateSqlStr = TextFileUtils.fileToString(updateSqlFile);
		updateSqlStr = updateSqlStr.replace("{nurseId}", nurseId)
								   .replace("{CurrentScheduleDate}", currentScheduleDateStr);
		
		sqlServerClient.executeSQL(updateSqlStr);
	}

	private void wipeoutTodaysAppointmentsByPatientAndDate(String patientId, String currentScheduleDateStr) throws Exception {
//		Path updateSqlFile = Paths.get("etc\\sql\\accessPoint\\wipeoutTodaysAppointmentsByPatientIdAndDate.sql");
//		String updateSqlStr = TextFileUtils.fileToString(updateSqlFile);
//		updateSqlStr = updateSqlStr.replace("{patientId}", patientId)
//				.replace("{CurrentScheduleDate}", currentScheduleDateStr);
//		
//		sqlServerClient.executeSQL(updateSqlStr);
		
		List<String> activeAppointmentIdList = findTodaysActiveAppointmentsByPatientId(patientId, currentScheduleDateStr);
		
		cancelAppointments(activeAppointmentIdList);
		

	}

	private void cancelAppointments(List<String> activeAppointmentIdList) throws Exception {
		Path sqlFile = Paths.get("etc\\sql\\accessPoint\\cancelAppointment.sql");
		
		String cancelDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		
		String sqlStr = TextFileUtils.fileToString(sqlFile);
		sqlStr = sqlStr.replace("{cancelDate}", cancelDate) ;
		
		
		for (String activeAppointmentId : activeAppointmentIdList) {
			LOG.info("Canceling appointment ... " + activeAppointmentId);
			sqlServerClient.executeSQL(sqlStr.replace("{appointmentId}", activeAppointmentId));
		}
		
	}

	private List<String> findTodaysActiveAppointmentsByPatientId(
			String patientId, String currentScheduleDateStr) throws Exception {
		Path sqlFile = Paths.get("etc\\sql\\accessPoint\\findTodaysActiveAppointmentsByPatientId.sql");
		
		String sqlStr = TextFileUtils.fileToString(sqlFile);
		sqlStr = sqlStr.replace("{patientId}", patientId) //TODO: USe patient id in query
								   .replace("{CurrentScheduleDate}", currentScheduleDateStr);
		
		List<String[]> results = sqlServerClient.runSQLQuery(sqlStr);
		
		List<String> activeAppointmentsByPatientIdList = new ArrayList<>();
		
		for (int i = 1; i < results.size(); i++) {
			activeAppointmentsByPatientIdList.add(results.get(i)[0]);
		}
		return activeAppointmentsByPatientIdList;
	}

	@Then("^clean up conflicts queue$")
	public void cleanUpConflictsQueue() throws Throwable {
		LOG.info("Wiping out previous appts...");
		String patientId = AccessPointInputData.Patient.id;
		String nurseId = AccessPointInputData.Nurse.id;
		String currentScheduleDateStr = new SimpleDateFormat("YYYY-MM-dd").format(new Date());
		
		List<String> patientActivityIdList = findPatientActivityIdList();
		
		cancelRequestedAppointments(patientActivityIdList);
		
		wipeoutTodaysAppointmentsByPatientAndDate(patientId, currentScheduleDateStr);
		
	}

	private void cancelRequestedAppointments(List<String> patientActivityIdList) throws Exception {
		Path sqlFile2 = Paths.get("etc\\sql\\accessPoint\\cancelRequestedAppointment.sql");
		String statement = TextFileUtils.fileToString(sqlFile2);
		
		for (String patientActivityId : patientActivityIdList) {
			LOG.info("Canceling PatientActivityId: " + patientActivityId);

			String exec = statement.replace("{PatientActivityId}", patientActivityId);
			
			sqlServerClient.executeSQL(exec);
		}
	}

	private List<String> findPatientActivityIdList() throws Exception {
		Path sqlFile = Paths.get("etc\\sql\\accessPoint\\findConflictPatientActivityIds.sql");
		List<String[]> results = sqlServerClient.runSQLQuery(sqlFile);
		
		List<String> patientActivityIdList = new ArrayList<>();
		
		for (int i = 1; i < results.size(); i++) {
			patientActivityIdList.add(results.get(i)[0]);
		}
		return patientActivityIdList;
	}
	
	@Then("^create conflicting appointments$")
	public void createConflictingAppointments() throws Throwable {
		
		System.out.println(AutomationProperties.getProperty("hello.world"));
		
		Date apptDate = AccessPointInputData.Appointment.date;
	    insertNextAppointment(apptDate);

	    Date conflictDate = DateUtils.addMinutes(apptDate, 10);
	    insertNextAppointment(conflictDate);
	    
	    AccessPointInputData.Appointment.conflictDate = conflictDate;
	}



	private void insertNextAppointment(Date apptDate) throws Exception {
		Path requestXmlPath = Paths.get("etc\\xml\\spXmlNextVisitAppointmentRequest.xml");
		String requestStr = TextFileUtils.fileToString(requestXmlPath);

		requestStr = requestStr.replace("{patientId}", AccessPointInputData.Patient.id)
								.replace("{nextAppointmentDate}", new SimpleDateFormat("MM/dd/YYYY HH:mm").format(apptDate))
								.replace("{prevAppointmentId}", AccessPointInputData.Appointment.previousApptId);
								
		Path sqlFile2 = Paths.get("etc\\sql\\accessPoint\\createNextAppointment.sql");
		String statement = TextFileUtils.fileToString(sqlFile2);
		
		String exec = statement.replace("{request}", requestStr);
			
		sqlServerClient.executeSQL(exec);
		
	}

	public static void main(String[] args) throws Throwable {
		
		AccessPointInputData.Patient.id = "1";
		String nurseId = AccessPointInputData.Nurse.id;
				
		new AccessPointDB().cleanUpConflictsQueue();
	}
}
