package com.express_scripts.field.nursing.automation.access.point.screens;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.express_scripts.field.nursing.automation.access.point.utils.BaseTesting;

import cucumber.api.java.en.Then;

public class ScreenUtilities extends BaseTesting{
	private static final Logger LOG = LogManager.getLogger(ScreenUtilities.class);
	
	private static int screenshotsCount = 0;
	
	@Then("^take screen shot:\"([^\"]*)\"$")
	public void takeScreenshot(String fileName) throws IOException {
		LOG.info("Taking Screen shot: " + fileName);
		screenshotsCount++;
		Path parentFolderPath = Paths.get("c:\\tmp");
		Path scenarioFolderPath = pathResolveOrCreate(parentFolderPath, AccessPointInputData.Metadata.scenarioName);
		Path scenarioExecFolderPath = pathResolveOrCreate(scenarioFolderPath, AccessPointInputData.Metadata.getExecutionId());
		String fileNameFull = String.format("%02d-%s.png"
				, screenshotsCount
				, fileName);
		Path fileNamePath = scenarioExecFolderPath.resolve(fileNameFull);
		_takeScreenshot(fileNamePath);
	}
	
	private static Path pathResolveOrCreate(Path basePath, String resolve) throws IOException{
		Path path = basePath;
		
		if (resolve!=null){
			path = basePath.resolve(resolve);
		}
		
		if (!path.toFile().exists()){
			path.toFile().mkdirs();
		}
		
		return path;
	}

	@Then("^click on button:\"([^\"]*)\"$")
	public void clickOnButton(String button) throws Throwable {
		
		clickButton(button);
		
		waitSeconds(10);

	}
	
	@Then("^click on link:\"([^\"]*)\"$")
	public void clickOnLink(String link) throws Throwable {
		LOG.info("Click on: " + link);
		
		clickLink(link);
	}

	@Then("^switch to frame:\"([^\"]*)\"$")
	public void switchToFrame(String frame){
		super.switchToFrame(frame);
	}
	
	@Then("^pause (\\d+) seconds$")
	public void pauseSeconds(int seconds) throws Throwable {
	    sleepMilliseconds(seconds * 1000);
	}
	
	@Then("^scroll to text:\"([^\"]*)\"$")
	public void scrollToText(String text){
		super.scrollTo(text);
		
		LOG.info("");
	}
	
	


}
