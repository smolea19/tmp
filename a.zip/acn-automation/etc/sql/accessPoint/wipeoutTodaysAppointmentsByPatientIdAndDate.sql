update PatientServiceVisit set currentScheduleDate =  '2016-10-20 07:00:00.000'
--select * from PatientServiceVisit
where patientSErviceVisitId 
  in (

  SELECT    psv.PatientServiceVisitId
FROM            dbo.Appointment a
inner join dbo.PatientServiceVisit psv on psv.PatientServiceVisitId = a.PatientServiceVisitId
where 1 = 1
and AppointmentId in (
SELECT [AppointmentId]
  FROM [dbo].[NSAppointmentPatient]
  where patientId = 39386 --39053 Sergio patient, 39386 TWO PINTO
  )
and cast(CurrentScheduleDate as date) = '{CurrentScheduleDate}'

)