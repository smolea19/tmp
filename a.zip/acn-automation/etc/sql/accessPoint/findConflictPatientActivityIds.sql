SELECT PatientActivityId
  FROM [dbo].[PatientActivity]
where ActivityStatusCd = 'NEW'