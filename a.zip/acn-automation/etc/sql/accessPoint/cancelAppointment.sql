EXEC [dbo].[spCancelAppointment] @PatientServiceVisitId = {appointmentId},@ReasonCodeId = 1, @UpdatedById = 1, @CancelSerieFlag = 0, @CancelDate = '{cancelDate}'
