update PatientServiceVisit set currentScheduleDate =  '2016-10-20 07:00:00.000'
where patientSErviceVisitId in (
SELECT [PatientServiceVisitId]
  FROM [dbo].[PatientServiceStaffAssigned]
  where 1 =1  
  and [StaffId] = {nurseId}  --444648 Sergio Nurse
  and [PatientServiceVisitId] in (select patientSErviceVisitId from PatientServiceVisit
where 1 = 1
and cast(CurrentScheduleDate as date) = '{CurrentScheduleDate}'
))