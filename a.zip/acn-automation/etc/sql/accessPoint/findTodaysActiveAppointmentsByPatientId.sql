select patientSErviceVisitId from PatientServiceVisit
where patientSErviceVisitId 
  in (

  SELECT    psv.PatientServiceVisitId
FROM            dbo.Appointment a
inner join dbo.PatientServiceVisit psv on psv.PatientServiceVisitId = a.PatientServiceVisitId
where 1 = 1
and mLookupApptStatusId != 1710
and AppointmentId in (
SELECT [AppointmentId]
  FROM [dbo].[NSAppointmentPatient]
  where patientId = 39386 --39053 Sergio patient, 39386 TWO PINTO
  )
and cast(CurrentScheduleDate as date) = '{CurrentScheduleDate}'

)